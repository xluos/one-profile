/**
 * macOS launchd autostart for the byted-lane daemon.
 *
 * Plist lives at ~/Library/LaunchAgents/com.byted-lane.daemon.plist and is
 * loaded with `launchctl load -w` (the -w persists across reboots). We use
 * the deprecated-but-still-working `launchctl load/unload` rather than the
 * newer bootstrap/bootout because the older interface is universal across
 * macOS 12+ and matches what most homebrew/launchd guides show.
 */

import { spawn } from 'node:child_process';
import { mkdir, readFile, stat, unlink, writeFile } from 'node:fs/promises';
import { homedir, platform } from 'node:os';
import { join } from 'node:path';
import { LOG_FILE, daemonEntry, projectRoot } from './daemon-ctrl.ts';

export const LAUNCHD_LABEL = 'com.byted-lane.daemon';
export const PLIST_PATH = join(homedir(), 'Library', 'LaunchAgents', `${LAUNCHD_LABEL}.plist`);

export function assertMac(): void {
  if (platform() !== 'darwin') {
    throw new Error(`autostart is macOS-only (current platform: ${platform()}). Skip this on Linux/Windows.`);
  }
}

// ─── Plist generation ───────────────────────────────────────────────

interface PlistInputs {
  bunPath: string;
  daemonPath: string;
  workingDir: string;
  logFile: string;
  home: string;
  pathEnv: string;
}

function buildPlist(p: PlistInputs): string {
  // Property-list strings need basic XML escaping. Paths shouldn't contain
  // <>&"' in any sane setup, but we escape anyway for paranoia.
  const esc = (s: string) => s.replace(/[<>&"']/g, (c) =>
    ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' })[c] ?? c
  );

  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>${esc(LAUNCHD_LABEL)}</string>
  <key>ProgramArguments</key>
  <array>
    <string>${esc(p.bunPath)}</string>
    <string>run</string>
    <string>${esc(p.daemonPath)}</string>
  </array>
  <key>WorkingDirectory</key>
  <string>${esc(p.workingDir)}</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>HOME</key>
    <string>${esc(p.home)}</string>
    <key>PATH</key>
    <string>${esc(p.pathEnv)}</string>
  </dict>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>${esc(p.logFile)}</string>
  <key>StandardErrorPath</key>
  <string>${esc(p.logFile)}</string>
  <key>ProcessType</key>
  <string>Background</string>
</dict>
</plist>
`;
}

async function findBunPath(): Promise<string> {
  // process.execPath is the bun binary that's running this CLI — guaranteed to exist.
  // Falling back to `which bun` would risk picking a different bun on PATH.
  return process.execPath;
}

// ─── Install / uninstall / status ──────────────────────────────────

export interface InstallResult {
  status: 'installed' | 'reinstalled';
  plistPath: string;
  plist: string;
}

export async function installAutostart(): Promise<InstallResult> {
  assertMac();

  const wasInstalled = await plistExists();

  // If already loaded, unload first so the launchctl load below picks up any
  // edits to the plist (e.g. project moved, bun upgraded).
  if (await isLoaded()) {
    await launchctl(['unload', '-w', PLIST_PATH]);
  }

  const plist = buildPlist({
    bunPath: await findBunPath(),
    daemonPath: daemonEntry(),
    workingDir: projectRoot(),
    logFile: LOG_FILE,
    home: homedir(),
    pathEnv: process.env.PATH || '/usr/local/bin:/usr/bin:/bin',
  });

  await mkdir(join(homedir(), 'Library', 'LaunchAgents'), { recursive: true });
  await writeFile(PLIST_PATH, plist, 'utf8');

  const { code, stderr } = await launchctl(['load', '-w', PLIST_PATH]);
  if (code !== 0) {
    throw new Error(`launchctl load failed (exit ${code}): ${stderr.trim() || '(no output)'}`);
  }

  return {
    status: wasInstalled ? 'reinstalled' : 'installed',
    plistPath: PLIST_PATH,
    plist,
  };
}

export interface UninstallResult {
  status: 'not-installed' | 'uninstalled';
}

export async function uninstallAutostart(): Promise<UninstallResult> {
  assertMac();
  if (!(await plistExists())) return { status: 'not-installed' };

  if (await isLoaded()) {
    // Unload errors here are non-fatal — we still want to remove the plist.
    await launchctl(['unload', '-w', PLIST_PATH]);
  }
  try { await unlink(PLIST_PATH); } catch { /* already gone */ }
  return { status: 'uninstalled' };
}

export interface AutostartStatus {
  installed: boolean;
  loaded: boolean;
  plistPath: string;
  pid: number | null;
  lastExitStatus: number | null;
}

export async function autostartStatus(): Promise<AutostartStatus> {
  // Don't assert mac here — let callers `status` even on Linux to get a clean
  // "not installed" rather than an exception.
  const installed = await plistExists();
  if (!installed) {
    return { installed: false, loaded: false, plistPath: PLIST_PATH, pid: null, lastExitStatus: null };
  }
  const loaded = await isLoaded();
  if (!loaded) {
    return { installed, loaded: false, plistPath: PLIST_PATH, pid: null, lastExitStatus: null };
  }
  const info = await launchctlList(LAUNCHD_LABEL);
  return {
    installed,
    loaded,
    plistPath: PLIST_PATH,
    pid: info.pid,
    lastExitStatus: info.lastExitStatus,
  };
}

// ─── launchctl helpers ─────────────────────────────────────────────

async function plistExists(): Promise<boolean> {
  try { await stat(PLIST_PATH); return true; } catch { return false; }
}

async function isLoaded(): Promise<boolean> {
  // `launchctl list LABEL` returns 0 if the agent is loaded, non-zero otherwise.
  const { code } = await launchctl(['list', LAUNCHD_LABEL]);
  return code === 0;
}

async function launchctlList(label: string): Promise<{ pid: number | null; lastExitStatus: number | null }> {
  // Output is a key=value plist-ish dump:
  //   "PID" = 12345;
  //   "LastExitStatus" = 0;
  // Parse with regex — no need to drag in a plist library for two fields.
  const { stdout } = await launchctl(['list', label]);
  const pidMatch = stdout.match(/"PID"\s*=\s*(\d+)/);
  const exitMatch = stdout.match(/"LastExitStatus"\s*=\s*(-?\d+)/);
  return {
    pid: pidMatch ? Number(pidMatch[1]) : null,
    lastExitStatus: exitMatch ? Number(exitMatch[1]) : null,
  };
}

async function launchctl(args: string[]): Promise<{ code: number; stdout: string; stderr: string }> {
  const proc = spawn('launchctl', args, { stdio: ['ignore', 'pipe', 'pipe'] });
  let stdout = '', stderr = '';
  proc.stdout?.on('data', (b) => { stdout += String(b); });
  proc.stderr?.on('data', (b) => { stderr += String(b); });
  const code = await new Promise<number>((resolve) => {
    proc.on('exit', (c) => resolve(c ?? 0));
  });
  return { code, stdout, stderr };
}

export async function readPlist(): Promise<string | null> {
  try { return await readFile(PLIST_PATH, 'utf8'); } catch { return null; }
}
