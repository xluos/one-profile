/**
 * Daemon lifecycle: start (detached), stop, restart, logs, isRunning.
 *
 * The CLI process exits immediately after `start`; the daemon survives via
 * detached + unref + ignore-stdio, with stdout/stderr redirected to a log
 * file under ~/.byted-lane/.
 */

import { spawn } from 'node:child_process';
import { mkdir, readFile, writeFile, unlink, open, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import {
  DAEMON_PING_URL,
  DAEMON_STATUS_URL,
  type DaemonStatus,
} from '../shared/protocol.ts';

export const STATE_DIR = join(homedir(), '.byted-lane');
export const PID_FILE = join(STATE_DIR, 'daemon.pid');
export const LOG_FILE = join(STATE_DIR, 'daemon.log');
export const STATE_FILE = join(STATE_DIR, 'state.json');

const PROJECT_ROOT = new URL('..', import.meta.url).pathname.replace(/\/$/, '');
const DAEMON_ENTRY = join(PROJECT_ROOT, 'daemon/index.ts');

// ─── Running detection ──────────────────────────────────────────────

/**
 * Authoritative check: does someone respond on the daemon's port? This works
 * regardless of how the daemon was launched (foreground, `start`, or launchd),
 * which is the right behavior — the user wants to know whether the bridge is
 * actually serving requests.
 */
export async function isRunning(timeoutMs = 500): Promise<boolean> {
  try {
    const res = await fetch(DAEMON_PING_URL, { signal: AbortSignal.timeout(timeoutMs) });
    return res.ok;
  } catch {
    return false;
  }
}

export async function readPidFile(): Promise<number | null> {
  try {
    const raw = await readFile(PID_FILE, 'utf8');
    const pid = Number(raw.trim());
    return Number.isFinite(pid) && pid > 0 ? pid : null;
  } catch { return null; }
}

async function writePidFile(pid: number): Promise<void> {
  await mkdir(STATE_DIR, { recursive: true });
  await writeFile(PID_FILE, String(pid), 'utf8');
}

async function clearPidFile(): Promise<void> {
  try { await unlink(PID_FILE); } catch { /* ignore */ }
}

// ─── start ─────────────────────────────────────────────────────────

export interface StartOptions {
  /** Override path to bun binary; defaults to `bun` on PATH. */
  bunPath?: string;
}

export interface StartResult {
  status: 'already-running' | 'started';
  pid?: number;
  source?: 'launchd' | 'manual';
}

export async function startDaemon(opts: StartOptions = {}): Promise<StartResult> {
  if (await isRunning()) {
    const pid = await tryGetRunningPid();
    return { status: 'already-running', pid: pid ?? undefined };
  }

  await mkdir(STATE_DIR, { recursive: true });

  // Open the log file for append; use the resulting fd for stdio redirection
  // so the daemon can write past our exit.
  const logHandle = await open(LOG_FILE, 'a');
  const logFd = logHandle.fd;

  const bun = opts.bunPath || 'bun';
  const proc = spawn(bun, ['run', DAEMON_ENTRY], {
    detached: true,
    stdio: ['ignore', logFd, logFd],
    env: { ...process.env },
    cwd: PROJECT_ROOT,
  });

  // Detach: parent must not wait on the child.
  proc.unref();
  await logHandle.close(); // child holds its own fd dup; we can close ours

  if (!proc.pid) throw new Error('failed to spawn daemon (no pid)');

  await writePidFile(proc.pid);

  // Verify the daemon actually came up — covers the case where the child
  // exited immediately (port in use, syntax error, etc).
  const ok = await waitForPing(3000);
  if (!ok) {
    await clearPidFile();
    throw new Error(`daemon did not become ready within 3s. Check ${LOG_FILE} for errors.`);
  }

  return { status: 'started', pid: proc.pid };
}

async function waitForPing(totalMs: number): Promise<boolean> {
  const deadline = Date.now() + totalMs;
  while (Date.now() < deadline) {
    if (await isRunning(300)) return true;
    await sleep(100);
  }
  return false;
}

async function tryGetRunningPid(): Promise<number | null> {
  // Prefer /status (authoritative — it's the actual daemon's pid)
  try {
    const res = await fetch(DAEMON_STATUS_URL, { signal: AbortSignal.timeout(500) });
    if (res.ok) {
      const body = await res.json() as DaemonStatus;
      if (typeof body.daemon?.pid === 'number') return body.daemon.pid;
    }
  } catch { /* fall through */ }
  return readPidFile();
}

// ─── stop ──────────────────────────────────────────────────────────

export interface StopResult {
  status: 'not-running' | 'stopped';
  pid?: number;
  killedVia?: 'pidfile' | 'port';
}

export async function stopDaemon(): Promise<StopResult> {
  const pid = await tryGetRunningPid();
  if (!pid) {
    if (!(await isRunning())) {
      await clearPidFile();
      return { status: 'not-running' };
    }
    // Running but we can't identify the pid — fall back to port kill.
    const portPid = await pidOnPort();
    if (portPid) {
      process.kill(portPid, 'SIGTERM');
      await waitForGone(2000);
      await clearPidFile();
      return { status: 'stopped', pid: portPid, killedVia: 'port' };
    }
    return { status: 'not-running' };
  }

  try {
    process.kill(pid, 'SIGTERM');
  } catch (err) {
    // ESRCH = already dead
    if ((err as NodeJS.ErrnoException).code !== 'ESRCH') throw err;
  }
  const gone = await waitForGone(2000);
  if (!gone) {
    try { process.kill(pid, 'SIGKILL'); } catch { /* ignore */ }
  }
  await clearPidFile();
  return { status: 'stopped', pid, killedVia: 'pidfile' };
}

async function waitForGone(totalMs: number): Promise<boolean> {
  const deadline = Date.now() + totalMs;
  while (Date.now() < deadline) {
    if (!(await isRunning(200))) return true;
    await sleep(100);
  }
  return !(await isRunning());
}

async function pidOnPort(): Promise<number | null> {
  // `lsof -ti:38999` returns the pid(s) listening on that port. Mac-only path,
  // matches the rest of this CLI's platform scope.
  const proc = spawn('lsof', ['-ti', ':38999'], { stdio: ['ignore', 'pipe', 'ignore'] });
  let out = '';
  if (!proc.stdout) return null;
  proc.stdout.on('data', (b) => { out += String(b); });
  await new Promise(r => proc.on('exit', r));
  const pid = Number(out.trim().split('\n')[0]);
  return Number.isFinite(pid) && pid > 0 ? pid : null;
}

// ─── logs ──────────────────────────────────────────────────────────

export async function logsExist(): Promise<boolean> {
  try { await stat(LOG_FILE); return true; } catch { return false; }
}

export function logFilePath(): string { return LOG_FILE; }

// ─── State (autostart prompt rate-limit) ───────────────────────────

interface CliState {
  lastAutostartPromptAt?: number;
}

async function readState(): Promise<CliState> {
  try {
    const raw = await readFile(STATE_FILE, 'utf8');
    return JSON.parse(raw) as CliState;
  } catch { return {}; }
}

async function writeState(s: CliState): Promise<void> {
  await mkdir(STATE_DIR, { recursive: true });
  await writeFile(STATE_FILE, JSON.stringify(s, null, 2), 'utf8');
}

const PROMPT_INTERVAL_MS = 24 * 60 * 60 * 1000;

export async function shouldShowAutostartPrompt(): Promise<boolean> {
  const s = await readState();
  if (!s.lastAutostartPromptAt) return true;
  return Date.now() - s.lastAutostartPromptAt > PROMPT_INTERVAL_MS;
}

export async function markAutostartPromptShown(): Promise<void> {
  const s = await readState();
  s.lastAutostartPromptAt = Date.now();
  await writeState(s);
}

// ─── Misc ──────────────────────────────────────────────────────────

function sleep(ms: number): Promise<void> { return new Promise(r => setTimeout(r, ms)); }

export function projectRoot(): string { return PROJECT_ROOT; }
export function daemonEntry(): string { return DAEMON_ENTRY; }
