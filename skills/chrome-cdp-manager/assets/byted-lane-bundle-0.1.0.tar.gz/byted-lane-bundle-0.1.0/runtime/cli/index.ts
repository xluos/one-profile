#!/usr/bin/env bun
/**
 * byted-lane CLI — controls the byted-lane daemon over HTTP.
 *
 * The daemon must be running (`bun run daemon`). All mutations land in
 * ~/.byted-lane/config.json, which the daemon broadcasts to the extension.
 */

import { spawn } from 'node:child_process';
import {
  DAEMON_BASE as DEFAULT_BASE,
  PROTOCOL_VERSION,
  type Config,
  type DaemonStatus,
  type EnvironmentProfile,
} from '../shared/protocol.ts';
import {
  isRunning,
  startDaemon,
  stopDaemon,
  logFilePath,
  logsExist,
  shouldShowAutostartPrompt,
  markAutostartPromptShown,
} from './daemon-ctrl.ts';
import {
  installAutostart,
  uninstallAutostart,
  autostartStatus,
} from './autostart.ts';
import { platform } from 'node:os';

// Allow tests / non-default ports without re-importing the constants module.
const DAEMON_BASE = process.env.BYTED_LANE_BASE
  || (process.env.BYTED_LANE_PORT ? `http://127.0.0.1:${process.env.BYTED_LANE_PORT}` : DEFAULT_BASE);
const DAEMON_PING_URL = `${DAEMON_BASE}/ping`;
const DAEMON_CONFIG_URL = `${DAEMON_BASE}/config`;
const DAEMON_STATUS_URL = `${DAEMON_BASE}/status`;

// ─── HTTP helpers ───────────────────────────────────────────────────

async function fetchJSON<T>(url: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, init);
  } catch (err) {
    fail(`cannot reach daemon at ${DAEMON_BASE} — is \`bun run daemon\` running?\n  ${(err as Error).message}`);
  }
  const text = await res.text();
  let body: unknown;
  try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
  if (!res.ok) {
    const msg = (body as { error?: string }).error ?? `HTTP ${res.status}`;
    fail(`daemon error: ${msg}`);
  }
  return body as T;
}

async function getConfig(): Promise<{ config: Config; revision: number }> {
  return fetchJSON(DAEMON_CONFIG_URL);
}

async function patchConfig(patch: Partial<Config>): Promise<{ config: Config; revision: number }> {
  return fetchJSON<{ ok: true; config: Config; revision: number }>(DAEMON_CONFIG_URL, {
    method: 'PATCH',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(patch),
  });
}

// ─── Output helpers ─────────────────────────────────────────────────

function fail(msg: string): never {
  console.error(`✗ ${msg}`);
  process.exit(1);
}

function ok(msg: string): void {
  console.log(`✓ ${msg}`);
}

function dump(obj: unknown): void {
  console.log(JSON.stringify(obj, null, 2));
}

// ─── Command handlers ───────────────────────────────────────────────

async function cmdStatus(): Promise<void> {
  const status = await fetchJSON<DaemonStatus>(DAEMON_STATUS_URL);
  console.log(`daemon       v${status.daemon.version}  pid ${status.daemon.pid}  up ${status.daemon.uptimeSec}s`);
  console.log(`config       ${status.config.path}  rev ${status.config.revision}`);
  if (status.extension.connected) {
    const e = status.extension;
    console.log(`extension    connected  v${e.version ?? '?'}  proto ${e.protocolVersion ?? '?'}`);
    if (e.lastAppliedRevision !== undefined) {
      const ok = e.lastAppliedOk ? '✓' : `✗ ${e.lastAppliedError ?? ''}`;
      console.log(`last apply   rev ${e.lastAppliedRevision} ${ok}`);
    }
  } else {
    console.log(`extension    not connected`);
  }
  if (status.autostart?.supported) {
    const a = status.autostart;
    const label = a.installed ? (a.loaded ? 'installed (loaded)' : 'installed (unloaded)') : 'not installed';
    console.log(`autostart    ${label}`);
    if (!a.installed) {
      console.log(`             run \`byted-lane autostart install\` so daemon comes back after reboot`);
    }
  }
}

async function cmdConfigShow(): Promise<void> {
  const { config, revision } = await getConfig();
  console.log(`# revision ${revision}`);
  dump(config);
}

async function cmdLaneSet(value: string, kind: 'env' | 'ppe' | 'header', headerName?: string): Promise<void> {
  const { config } = await getConfig();
  const headers = { ...config.lane.headers };
  let key: string;
  if (kind === 'env') key = 'x-tt-env';
  else if (kind === 'ppe') key = 'x-use-ppe';
  else if (kind === 'header' && headerName) key = headerName.toLowerCase();
  else fail('lane set: must specify --env / --ppe / --header <name>');
  headers[key] = value;
  const { revision } = await patchConfig({ lane: { ...config.lane, enabled: true, headers } });
  ok(`lane: ${key} = ${value}  (rev ${revision})`);
}

async function cmdLaneClear(): Promise<void> {
  const { revision } = await patchConfig({ lane: { enabled: false, headers: {}, excludedDomains: [], routes: [] } });
  ok(`lane cleared  (rev ${revision})`);
}

async function cmdProxySetMode(mode: 'direct' | 'system' | 'fixed', server?: string): Promise<void> {
  const patch: Partial<Config> = mode === 'fixed'
    ? { proxy: { mode, server } }
    : { proxy: { mode } };
  const { revision, config } = await patchConfig(patch);
  const detail = mode === 'fixed'
    ? `fixed (Chrome → ${config.proxy.server ?? server ?? '?'})`
    : mode === 'system'
      ? 'system (Chrome → OS proxy)'
      : 'direct (Chrome bypasses OS proxy)';
  ok(`proxy ${detail}  (rev ${revision})`);
}

async function cmdLaneToggle(enabled: boolean): Promise<void> {
  const { config } = await getConfig();
  const { revision } = await patchConfig({ lane: { ...config.lane, enabled } });
  ok(`lane ${enabled ? 'on' : 'off'}  (rev ${revision})`);
}

async function cmdLaneRouteList(): Promise<void> {
  const { config } = await getConfig();
  const routes = config.lane.routes ?? [];
  if (routes.length === 0) {
    console.log('no domain routes configured');
    return;
  }
  for (const r of routes) {
    console.log(`  ${r.env}  →  ${r.domains.join(', ')}`);
  }
}

async function cmdLaneRouteAdd(env: string, domainArg: string): Promise<void> {
  const newDomains = domainArg.split(',').map(d => d.trim().toLowerCase()).filter(Boolean);
  if (newDomains.length === 0) fail('lane route add: --domain must specify at least one domain');

  const { config } = await getConfig();
  const routes = [...(config.lane.routes ?? [])];

  // Remove these domains from any existing route (one domain = one route).
  const domainSet = new Set(newDomains);
  for (const r of routes) {
    r.domains = r.domains.filter(d => !domainSet.has(d));
  }

  // Merge into existing route with same env, or create new.
  const existing = routes.find(r => r.env === env);
  if (existing) {
    const merged = new Set([...existing.domains, ...newDomains]);
    existing.domains = [...merged];
  } else {
    routes.push({ domains: newDomains, env });
  }

  // Drop routes with empty domains (drained by domain reassignment above).
  const cleaned = routes.filter(r => r.domains.length > 0);

  const { revision } = await patchConfig({
    lane: { ...config.lane, enabled: true, routes: cleaned },
  });
  ok(`route: ${env} → ${newDomains.join(', ')}  (rev ${revision})`);
}

async function cmdLaneRouteRemove(target: string, byDomain: boolean): Promise<void> {
  const { config } = await getConfig();
  let routes = [...(config.lane.routes ?? [])];

  if (byDomain) {
    const domain = target.trim().toLowerCase();
    for (const r of routes) {
      r.domains = r.domains.filter(d => d !== domain);
    }
    routes = routes.filter(r => r.domains.length > 0);
  } else {
    const before = routes.length;
    routes = routes.filter(r => r.env !== target);
    if (routes.length === before) fail(`no route with env "${target}"`);
  }

  const { revision } = await patchConfig({
    lane: { ...config.lane, routes },
  });
  ok(`route removed  (rev ${revision})`);
}

async function cmdLaneRouteClear(): Promise<void> {
  const { config } = await getConfig();
  const { revision } = await patchConfig({
    lane: { ...config.lane, routes: [] },
  });
  ok(`all routes cleared  (rev ${revision})`);
}

function splitDomains(value: string): string[] {
  return [...new Set(value.split(',').map(domain => domain.trim().toLowerCase()).filter(Boolean))];
}

function findEnvironment(environments: EnvironmentProfile[], env: string): EnvironmentProfile {
  const profile = environments.find(item => item.env === env);
  if (!profile) fail(`environment "${env}" not found`);
  return profile;
}

async function cmdEnvList(): Promise<void> {
  const { config } = await getConfig();
  if (config.environments.length === 0) {
    console.log('no environments configured');
    return;
  }
  for (const profile of config.environments) {
    const include = profile.includeFilters.filter(item => item.enabled).map(item => item.value);
    const exclude = profile.excludeFilters.filter(item => item.enabled).map(item => item.value);
    console.log(`${profile.enabled ? 'on ' : 'off'}  ${profile.env || '(unnamed)'}`);
    if (include.length) console.log(`     include  ${include.join(', ')}`);
    if (exclude.length) console.log(`     exclude  ${exclude.join(', ')}`);
  }
}

async function cmdEnvAdd(env: string, enabled: boolean): Promise<void> {
  const { config } = await getConfig();
  if (config.environments.some(item => item.env === env)) fail(`environment "${env}" already exists`);
  const now = Date.now();
  const profile: EnvironmentProfile = {
    id: crypto.randomUUID().slice(0, 8),
    env,
    enabled,
    headers: {},
    includeFilters: [],
    excludeFilters: [],
    source: 'cli',
    createdAt: now,
    updatedAt: now,
  };
  const { revision } = await patchConfig({ environments: [...config.environments, profile] });
  ok(`environment ${env} added${enabled ? ' and enabled' : ''}  (rev ${revision})`);
}

async function cmdEnvRemove(env: string): Promise<void> {
  const { config } = await getConfig();
  findEnvironment(config.environments, env);
  const environments = config.environments.filter(item => item.env !== env);
  const { revision } = await patchConfig({ environments });
  ok(`environment ${env} removed  (rev ${revision})`);
}

async function cmdEnvToggle(env: string, enabled: boolean): Promise<void> {
  const { config } = await getConfig();
  findEnvironment(config.environments, env);
  const environments = config.environments.map(item => item.env === env
    ? { ...item, enabled, updatedAt: Date.now() }
    : item);
  const { revision } = await patchConfig({ environments });
  ok(`environment ${env} ${enabled ? 'on' : 'off'}  (rev ${revision})`);
}

async function cmdEnvRename(env: string, nextEnv: string): Promise<void> {
  const { config } = await getConfig();
  findEnvironment(config.environments, env);
  if (config.environments.some(item => item.env === nextEnv)) fail(`environment "${nextEnv}" already exists`);
  const environments = config.environments.map(item => item.env === env
    ? { ...item, env: nextEnv, updatedAt: Date.now() }
    : item);
  const { revision } = await patchConfig({ environments });
  ok(`environment ${env} renamed to ${nextEnv}  (rev ${revision})`);
}

async function cmdEnvFilter(
  action: 'add' | 'remove',
  env: string,
  kind: 'includeFilters' | 'excludeFilters',
  domainArg: string,
): Promise<void> {
  const domains = splitDomains(domainArg);
  if (domains.length === 0) fail(`env filter ${action}: domain list cannot be empty`);
  const { config } = await getConfig();
  findEnvironment(config.environments, env);
  const environments = config.environments.map(profile => {
    if (profile.env !== env) return profile;
    const current = profile[kind];
    const next = action === 'add'
      ? [...current, ...domains
          .filter(domain => !current.some(filter => filter.value === domain))
          .map(value => ({ id: crypto.randomUUID().slice(0, 8), value, enabled: true }))]
      : current.filter(filter => !domains.includes(filter.value));
    return { ...profile, [kind]: next, updatedAt: Date.now() };
  });
  const { revision } = await patchConfig({ environments });
  const label = kind === 'includeFilters' ? 'include' : 'exclude';
  ok(`${label} filter ${action === 'add' ? 'added to' : 'removed from'} ${env}: ${domains.join(', ')}  (rev ${revision})`);
}

async function cmdPing(): Promise<void> {
  const res = await fetchJSON<{ ok: boolean; version: string }>(DAEMON_PING_URL);
  ok(`daemon up, v${res.version}`);
}

// ─── Daemon lifecycle ───────────────────────────────────────────────

async function cmdStart(): Promise<void> {
  const result = await startDaemon();
  if (result.status === 'already-running') {
    console.log(`daemon already running${result.pid ? ` (pid ${result.pid})` : ''}`);
  } else {
    ok(`daemon started (pid ${result.pid})`);
    console.log(`logs: ${logFilePath()}`);
  }
  await maybePromptAutostart();
}

async function cmdStop(): Promise<void> {
  // If launchd is managing the daemon, plain SIGTERM is futile (KeepAlive
  // restarts immediately). Unload first; user runs `byted-lane start` to bring
  // it back, or `autostart uninstall` to disable persistence entirely.
  if (platform() === 'darwin') {
    const a = await autostartStatus();
    if (a.loaded) {
      const { uninstallAutostart: _ } = { uninstallAutostart };
      await spawnLaunchctl(['unload', '-w', a.plistPath]);
      console.log('daemon stopped (autostart unloaded; run `byted-lane start` to bring back, or `autostart uninstall` to disable persistence)');
      return;
    }
  }
  const r = await stopDaemon();
  if (r.status === 'not-running') console.log('daemon not running');
  else ok(`daemon stopped (pid ${r.pid}, via ${r.killedVia})`);
}

async function spawnLaunchctl(args: string[]): Promise<void> {
  await new Promise<void>((resolve) => {
    const p = spawn('launchctl', args, { stdio: 'ignore' });
    p.on('exit', () => resolve());
  });
}

async function cmdRestart(): Promise<void> {
  await cmdStop();
  // Give the OS a beat to release the port.
  await new Promise(r => setTimeout(r, 200));
  // If autostart is loaded again (cmdStop unloaded), reload it; else spawn manually.
  if (platform() === 'darwin') {
    const a = await autostartStatus();
    if (a.installed && !a.loaded) {
      await spawnLaunchctl(['load', '-w', a.plistPath]);
      // Verify it came back
      const t0 = Date.now();
      while (Date.now() - t0 < 3000) {
        if (await isRunning(300)) { ok('daemon restarted (via launchd)'); return; }
        await new Promise(r => setTimeout(r, 100));
      }
      fail('daemon failed to restart via launchd; check logs');
    }
  }
  await cmdStart();
}

async function cmdLogs(follow: boolean): Promise<void> {
  if (!(await logsExist())) {
    console.log(`no log file yet at ${logFilePath()} — start the daemon first`);
    return;
  }
  const args = follow ? ['-n', '50', '-f', logFilePath()] : ['-n', '200', logFilePath()];
  const proc = spawn('tail', args, { stdio: 'inherit' });
  await new Promise<void>((resolve) => proc.on('exit', () => resolve()));
}

// ─── Autostart ──────────────────────────────────────────────────────

async function cmdAutostartInstall(): Promise<void> {
  const r = await installAutostart();
  ok(`autostart ${r.status} → ${r.plistPath}`);
  console.log('daemon will start on login and auto-restart if it dies.');
}

async function cmdAutostartUninstall(): Promise<void> {
  const r = await uninstallAutostart();
  if (r.status === 'not-installed') console.log('autostart was not installed');
  else ok('autostart uninstalled');
}

async function cmdAutostartStatus(): Promise<void> {
  const s = await autostartStatus();
  console.log(`installed     ${s.installed ? 'yes' : 'no'}  (${s.plistPath})`);
  console.log(`loaded        ${s.loaded ? 'yes' : 'no'}`);
  if (s.pid !== null) console.log(`launchd pid   ${s.pid}`);
  if (s.lastExitStatus !== null) {
    console.log(`last exit     ${s.lastExitStatus}${s.lastExitStatus !== 0 ? ' (non-zero — check logs)' : ''}`);
  }
}

async function maybePromptAutostart(): Promise<void> {
  if (platform() !== 'darwin') return;
  const s = await autostartStatus();
  if (s.installed) return;
  if (!(await shouldShowAutostartPrompt())) return;
  console.log('');
  console.log('hint: run `byted-lane autostart install` to start automatically on login.');
  console.log('      (this hint shows at most once per 24h)');
  await markAutostartPromptShown();
}

// ─── Argument parsing ───────────────────────────────────────────────

const HELP = `byted-lane CLI

Daemon lifecycle:
  byted-lane start                         # start daemon in background
  byted-lane stop                          # stop daemon (or unload launchd)
  byted-lane restart
  byted-lane logs [-f]                     # tail daemon log
  byted-lane status                        # daemon + extension state
  byted-lane ping

Autostart (macOS launchd):
  byted-lane autostart install             # run at login + auto-restart
  byted-lane autostart uninstall
  byted-lane autostart status

Config:
  byted-lane config show

Environments (shared with the extension sidebar):
  byted-lane env list
  byted-lane env add <env> [--on]
  byted-lane env remove <env>
  byted-lane env on|off <env>
  byted-lane env rename <env> <new-env>
  byted-lane env filter add|remove <env> --include <d1>[,<d2>]
  byted-lane env filter add|remove <env> --exclude <d1>[,<d2>]

Lane (request headers — prefer domain-limited Environment Profiles):
  byted-lane lane set <value> --env|--ppe|--header <name>
  byted-lane lane clear
  byted-lane lane on|off

Lane routes (domain-specific env override):
  byted-lane lane route list
  byted-lane lane route add <env> --domain <d1>[,<d2>]
  byted-lane lane route remove <env>
  byted-lane lane route remove --domain <d>
  byted-lane lane route clear

Proxy (Chrome routing — per-URL routing is the OS tool's job, byted-lane just picks the upstream):
  byted-lane proxy direct                  # Chrome bypasses any OS proxy
  byted-lane proxy system                  # Chrome follows the OS proxy (alias: \`proxy on\`)
  byted-lane proxy fixed <url>             # Chrome routes through <url>, e.g. http://127.0.0.1:8899
                                           #   (\`proxy off\` is an alias for \`proxy direct\`)

Examples:
  byted-lane start
  byted-lane lane set ppe_xxx --env        # x-use-ppe auto-added for ppe_*
  byted-lane lane route add ppe_a --domain api.service-a.com
  byted-lane lane route add boe_b --domain api.service-b.com,cdn.b.com
  byted-lane proxy system                  # let Chrome use OS proxy
  byted-lane proxy fixed http://127.0.0.1:8899
`;

interface Parsed {
  positional: string[];
  flags: Record<string, string | boolean>;
}

function parse(argv: string[]): Parsed {
  const positional: string[] = [];
  const flags: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]!;
    if (a.startsWith('--')) {
      const name = a.slice(2);
      const next = argv[i + 1];
      if (next !== undefined && !next.startsWith('--')) { flags[name] = next; i++; }
      else flags[name] = true;
    } else {
      positional.push(a);
    }
  }
  return { positional, flags };
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.length === 0 || args[0] === 'help' || args[0] === '--help' || args[0] === '-h') {
    console.log(HELP);
    return;
  }
  if (args[0] === '--version' || args[0] === '-v' || args[0] === 'version') {
    console.log(PROTOCOL_VERSION);
    return;
  }

  const { positional, flags } = parse(args);
  const [group, sub, ...rest] = positional;

  switch (group) {
    case 'ping': await cmdPing(); return;
    case 'status': await cmdStatus(); return;
    case 'start': await cmdStart(); return;
    case 'stop': await cmdStop(); return;
    case 'restart': await cmdRestart(); return;
    case 'logs': await cmdLogs(Boolean(flags.f || flags.follow)); return;
    case 'autostart': {
      if (sub === 'install') return cmdAutostartInstall();
      if (sub === 'uninstall') return cmdAutostartUninstall();
      if (sub === 'status') return cmdAutostartStatus();
      fail(`unknown autostart subcommand: ${sub} (expected install|uninstall|status)`);
      break;
    }
    case 'config':
      if (sub === 'show') return cmdConfigShow();
      fail(`unknown config subcommand: ${sub}`);
      break;
    case 'env': {
      if (sub === 'list' || !sub) return cmdEnvList();
      if (sub === 'add') {
        const env = rest[0];
        if (!env) fail('env add: missing env');
        return cmdEnvAdd(env, Boolean(flags.on));
      }
      if (sub === 'remove') {
        const env = rest[0];
        if (!env) fail('env remove: missing env');
        return cmdEnvRemove(env);
      }
      if (sub === 'on' || sub === 'off') {
        const env = rest[0];
        if (!env) fail(`env ${sub}: missing env`);
        return cmdEnvToggle(env, sub === 'on');
      }
      if (sub === 'rename') {
        const [env, nextEnv] = rest;
        if (!env || !nextEnv) fail('env rename: expected <env> <new-env>');
        return cmdEnvRename(env, nextEnv);
      }
      if (sub === 'filter') {
        const action = rest[0];
        const env = rest[1];
        if (action !== 'add' && action !== 'remove') fail('env filter: expected add|remove');
        if (!env) fail(`env filter ${action}: missing env`);
        const hasInclude = typeof flags.include === 'string';
        const hasExclude = typeof flags.exclude === 'string';
        if (hasInclude === hasExclude) fail(`env filter ${action}: pass exactly one of --include or --exclude`);
        return cmdEnvFilter(
          action,
          env,
          hasInclude ? 'includeFilters' : 'excludeFilters',
          (hasInclude ? flags.include : flags.exclude) as string,
        );
      }
      fail(`unknown env subcommand: ${sub}`);
      break;
    }
    case 'lane': {
      if (sub === 'set') {
        const value = rest[0];
        if (!value) fail('lane set: missing value');
        if (flags.env) return cmdLaneSet(value, 'env');
        if (flags.ppe) return cmdLaneSet(value, 'ppe');
        if (typeof flags.header === 'string') return cmdLaneSet(value, 'header', flags.header);
        fail('lane set: pass --env, --ppe, or --header <name>');
      }
      if (sub === 'clear') return cmdLaneClear();
      if (sub === 'on') return cmdLaneToggle(true);
      if (sub === 'off') return cmdLaneToggle(false);
      if (sub === 'route') {
        const routeSub = rest[0];
        if (routeSub === 'list' || !routeSub) return cmdLaneRouteList();
        if (routeSub === 'add') {
          const env = rest[1];
          if (!env) fail('lane route add: missing env value');
          const domain = flags.domain;
          if (typeof domain !== 'string') fail('lane route add: --domain <domains> required');
          return cmdLaneRouteAdd(env, domain);
        }
        if (routeSub === 'remove') {
          if (typeof flags.domain === 'string') return cmdLaneRouteRemove(flags.domain, true);
          const env = rest[1];
          if (!env) fail('lane route remove: specify env or --domain <d>');
          return cmdLaneRouteRemove(env, false);
        }
        if (routeSub === 'clear') return cmdLaneRouteClear();
        fail(`unknown lane route subcommand: ${routeSub}`);
      }
      fail(`unknown lane subcommand: ${sub}`);
      break;
    }
    case 'proxy': {
      // on/off are kept as ergonomic aliases — they map to system/direct, the
      // shape the daemon now stores. New code (and the popup) speaks mode names.
      if (sub === 'on' || sub === 'system') return cmdProxySetMode('system');
      if (sub === 'off' || sub === 'direct') return cmdProxySetMode('direct');
      if (sub === 'fixed') {
        const server = rest[0];
        if (!server) fail('proxy fixed: missing server URL (e.g. http://127.0.0.1:8899)');
        return cmdProxySetMode('fixed', server);
      }
      fail(`unknown proxy subcommand: ${sub} (expected direct|system|fixed|on|off)`);
      break;
    }
    default:
      fail(`unknown command: ${group}\n\n${HELP}`);
  }
}

main().catch((err) => fail((err as Error).message));
