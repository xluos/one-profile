/**
 * byted-lane extension — service worker.
 *
 * Connects to the local daemon over WebSocket, applies pushed Config to the
 * browser via declarativeNetRequest (lane headers) + chrome.proxy (per-host
 * routing), and ACKs each revision so the daemon's /status reflects reality.
 */

import {
  DAEMON_CONFIG_URL,
  DAEMON_PING_URL,
  DAEMON_STATUS_URL,
  DAEMON_WS_URL,
  PROTOCOL_VERSION,
  WS_RECONNECT_BASE_MS,
  WS_RECONNECT_MAX_MS,
  type AutostartState,
  type ClientMessage,
  type Config,
  type DaemonStatus,
  type LaneRoute,
  type ServerMessage,
} from '../../shared/protocol.ts';
import { ApplyCoordinator, type ApplyOutcome } from './apply-coordinator.ts';

// ─── Constants ──────────────────────────────────────────────────────

/** Reserved DNR rule ID range so we never collide with other extensions / future rules. */
const RULE_ID_BASE = 10_000;
const RULE_ID_LIMIT = 19_999;
const KEEPALIVE_ALARM = 'byted-lane:keepalive';
const KEEPALIVE_PERIOD_MIN = 0.5; // 30s — Chrome's minimum for unpacked extensions
const KEEPALIVE_INTERVAL_MS = 20_000;
const MAX_EAGER_RECONNECT = 6;
const PING_TIMEOUT_MS = 1000;
const APPLY_CONFIRM_TIMEOUT_MS = 2000;
const AUTOSTART_CACHE_TTL_MS = 60_000;

const STATE_KEY = 'byted_lane_state_v1';
const AUTOSTART_CACHE_KEY = 'byted_lane_autostart_v1';
const PROXY_RECOVERY_KEY = 'byted_lane_proxy_recovery_v1';
type Persisted = {
  config: Config | null;
  revision: number;
  lastAppliedOk: boolean | null;
  lastAppliedError: string | null;
};
type PersistedAutostart = {
  value: AutostartState;
  fetchedAt: number;
};
type StartupCache = {
  state: Persisted | null;
  autostart: PersistedAutostart | null;
  proxyRecovered: boolean;
};

/**
 * Lane snapshots the user has seen, newest first. Recorded after each
 * successful apply so popup can offer one-click revert/switch. Dedup is by
 * canonical signature (sorted headers); identical snapshots move to the front
 * rather than stacking.
 */
const HISTORY_KEY = 'byted_lane_history_v1';
const MAX_HISTORY = 10;
interface LaneHistoryEntry {
  headers: Record<string, string>;
  excludedDomains?: string[];
  routes?: LaneRoute[];
  ts: number;
}

// ─── Module state ───────────────────────────────────────────────────

let ws: WebSocket | null = null;
let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
let reconnectAttempts = 0;
let initialized = false;
let alarmEnsured = false;
let ensureAlarmPromise: Promise<void> | null = null;
let connectPromise: Promise<void> | null = null;
let lastConfig: Config | null = null;
let swKeepAliveTimer: ReturnType<typeof setInterval> | null = null;
let configApplyQueue: Promise<void> = Promise.resolve();
let autostartCache: PersistedAutostart | null = null;
let autostartRefreshPromise: Promise<void> | null = null;
let startupCache: StartupCache | null = null;
let startupCachePromise: Promise<StartupCache> | null = null;
const applyCoordinator = new ApplyCoordinator(APPLY_CONFIRM_TIMEOUT_MS);

// ─── Logging (tee to daemon) ────────────────────────────────────────

const _log = console.log.bind(console);
const _warn = console.warn.bind(console);
const _err = console.error.bind(console);

function teeToDaemon(level: 'info' | 'warn' | 'error', args: unknown[]): void {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  try {
    const msg = args.map(a => typeof a === 'string' ? a : safeJSON(a)).join(' ');
    const out: ClientMessage = { type: 'log', level, msg, ts: Date.now() };
    ws.send(JSON.stringify(out));
  } catch { /* ignore */ }
}
console.log = (...a: unknown[]) => { _log(...a); teeToDaemon('info', a); };
console.warn = (...a: unknown[]) => { _warn(...a); teeToDaemon('warn', a); };
console.error = (...a: unknown[]) => { _err(...a); teeToDaemon('error', a); };

function safeJSON(v: unknown): string {
  try { return JSON.stringify(v); } catch { return String(v); }
}

// ─── WebSocket connection ───────────────────────────────────────────

/**
 * `new WebSocket()` failures log ERR_CONNECTION_REFUSED to chrome://extensions
 * before any handler can suppress them. The /ping HTTP probe is catchable, so
 * we gate every connect attempt on it. This is the single most important trick
 * for making a "daemon-required" extension feel non-noisy when daemon is down.
 */
function ensureAlarm(): Promise<void> {
  if (alarmEnsured) return Promise.resolve();
  if (ensureAlarmPromise) return ensureAlarmPromise;

  ensureAlarmPromise = (async () => {
    const existing = await chrome.alarms.get(KEEPALIVE_ALARM);
    if (!existing) {
      chrome.alarms.create(KEEPALIVE_ALARM, {
        delayInMinutes: KEEPALIVE_PERIOD_MIN,
        periodInMinutes: KEEPALIVE_PERIOD_MIN,
      });
      console.warn('[byted-lane] keepalive alarm was missing — recreated');
    }
    alarmEnsured = true;
  })().finally(() => {
    ensureAlarmPromise = null;
  });
  return ensureAlarmPromise;
}

/**
 * Chrome MV3 may terminate a worker that only owns an idle WebSocket. Send
 * real bidirectional traffic below the 30s idle threshold: the outgoing
 * keepalive and daemon ACK both count as activity. The alarm remains a
 * fallback wake-up path if Chrome suspends timers or the socket drops.
 */
function startSWKeepAlive(): void {
  if (swKeepAliveTimer) return;
  swKeepAliveTimer = setInterval(() => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    const keepalive: ClientMessage = { type: 'keepalive', ts: Date.now() };
    try { ws.send(JSON.stringify(keepalive)); } catch { /* onclose reconnects */ }
  }, KEEPALIVE_INTERVAL_MS);
}

function stopSWKeepAlive(): void {
  if (swKeepAliveTimer) { clearInterval(swKeepAliveTimer); swKeepAliveTimer = null; }
}

function connect(): Promise<void> {
  if (ws?.readyState === WebSocket.OPEN) return Promise.resolve();
  if (connectPromise) return connectPromise;
  if (ws?.readyState === WebSocket.CONNECTING) return Promise.resolve();

  connectPromise = connectOnce().finally(() => {
    connectPromise = null;
  });
  return connectPromise;
}

async function connectOnce(): Promise<void> {
  await ensureAlarm();

  try {
    const res = await fetch(DAEMON_PING_URL, { signal: AbortSignal.timeout(PING_TIMEOUT_MS) });
    if (!res.ok) return;
  } catch {
    return; // daemon not running — silently skip
  }

  try {
    ws = new WebSocket(DAEMON_WS_URL);
  } catch {
    scheduleReconnect();
    return;
  }

  // Await the WS handshake so the calling event handler's Promise keeps the
  // SW alive through it. Once open, startSWKeepAlive() takes over.
  const wsRef = ws;
  wsRef.onmessage = (event) => {
    let msg: ServerMessage;
    try { msg = JSON.parse(String(event.data)) as ServerMessage; }
    catch { console.warn('[byted-lane] bad server message:', event.data); return; }
    if (msg.type === 'config') enqueueConfig(msg.config, msg.revision);
    // keepaliveAck intentionally needs no work: receiving the WS event is the
    // activity signal. Avoid logging every ACK and growing daemon.log.
  };
  await new Promise<void>((resolve) => {
    wsRef.onopen = () => {
      reconnectAttempts = 0;
      if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
      // Daemon revisions restart from 1 after each daemon process restart, so
      // apply confirmations are valid only within the current WS connection.
      applyCoordinator.reset();
      startSWKeepAlive();
      const hello: ClientMessage = {
        type: 'hello',
        extensionVersion: chrome.runtime.getManifest().version,
        protocolVersion: PROTOCOL_VERSION,
      };
      wsRef.send(JSON.stringify(hello));
      console.log('[byted-lane] connected to daemon');
      void updateActionUI();
      resolve();
    };

    wsRef.onclose = () => {
      stopSWKeepAlive();
      // A manual reconnect can replace ws before this old socket closes.
      if (ws === wsRef) {
        ws = null;
        console.log('[byted-lane] disconnected');
        void updateActionUI();
        scheduleReconnect();
      }
      resolve();
    };

    wsRef.onerror = () => { wsRef.close(); };
  });
}

function scheduleReconnect(): void {
  if (reconnectTimer) return;
  reconnectAttempts++;
  if (reconnectAttempts > MAX_EAGER_RECONNECT) return; // alarm picks up
  const delay = Math.min(WS_RECONNECT_BASE_MS * 2 ** (reconnectAttempts - 1), WS_RECONNECT_MAX_MS);
  reconnectTimer = setTimeout(() => { reconnectTimer = null; void connect(); }, delay);
}

// ─── Config application ─────────────────────────────────────────────

function enqueueConfig(config: Config, revision: number): void {
  configApplyQueue = configApplyQueue
    .then(() => handleConfig(config, revision))
    .catch(err => console.error('[byted-lane] config apply queue failed:', (err as Error).message));
}

async function handleConfig(config: Config, revision: number): Promise<void> {
  console.log(`[byted-lane] applying revision ${revision}`);
  // Capture the OUTGOING lane before lastConfig is overwritten — that's what
  // belongs in history (the snapshot the user is leaving), not the one they're
  // switching to. Recording the incoming lane and then filtering it out in the
  // popup meant the first edit always produced an empty history.
  const previousLane = lastConfig?.lane ?? null;
  let applied: ClientMessage;
  let appliedOk = false;
  try {
    await applyLane(config);
    await applyProxy(config);
    await persistState({ config, revision, lastAppliedOk: true, lastAppliedError: null });
    applied = { type: 'applied', revision, ok: true };
    appliedOk = true;
    console.log(`[byted-lane] applied revision ${revision}`);
  } catch (err) {
    const message = (err as Error).message ?? String(err);
    await persistState({ config, revision, lastAppliedOk: false, lastAppliedError: message });
    applied = { type: 'applied', revision, ok: false, error: message };
    console.error(`[byted-lane] apply failed:`, message);
  }
  lastConfig = config;
  if (appliedOk && previousLane && isLaneWorthRecording(previousLane)) {
    const prevSig = laneSignature(previousLane.headers, previousLane.routes, previousLane.excludedDomains);
    const curSig = laneSignature(config.lane.headers, config.lane.routes, config.lane.excludedDomains);
    // Skip no-op transitions (re-apply on reconnect, idempotent broadcasts).
    if (prevSig !== curSig) await recordLaneHistory(previousLane);
  }
  void updateActionUI();
  applyCoordinator.settle(applied as ApplyOutcome);
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(applied));
}

function laneSignature(headers: Record<string, string>, routes?: LaneRoute[], excludedDomains?: string[]): string {
  const sortedHeaders: Record<string, string> = {};
  for (const k of Object.keys(headers).sort()) sortedHeaders[k] = headers[k]!;
  const sortedRoutes = (routes ?? [])
    .map(r => ({ domains: [...r.domains].sort(), excludedDomains: [...(r.excludedDomains ?? [])].sort(), env: r.env }))
    .sort((a, b) => a.env.localeCompare(b.env));
  return JSON.stringify({ headers: sortedHeaders, excludedDomains: [...(excludedDomains ?? [])].sort(), routes: sortedRoutes });
}

function isLaneWorthRecording(lane: Config['lane']): boolean {
  return !!lane.headers['x-tt-env'] || (lane.routes ?? []).length > 0;
}

async function recordLaneHistory(lane: Config['lane']): Promise<void> {
  if (!isLaneWorthRecording(lane)) return;

  const sig = laneSignature(lane.headers, lane.routes, lane.excludedDomains);
  const raw = await chrome.storage.local.get(HISTORY_KEY);
  const prev = (raw[HISTORY_KEY] as LaneHistoryEntry[] | undefined) ?? [];
  const filtered = prev.filter(e => laneSignature(e.headers ?? {}, e.routes, e.excludedDomains) !== sig);
  const entry: LaneHistoryEntry = { headers: { ...lane.headers }, ts: Date.now() };
  if (lane.excludedDomains?.length) entry.excludedDomains = lane.excludedDomains;
  if (lane.routes && lane.routes.length > 0) entry.routes = lane.routes;
  const next: LaneHistoryEntry[] = [entry, ...filtered].slice(0, MAX_HISTORY);
  await chrome.storage.local.set({ [HISTORY_KEY]: next });
}

async function applyLane(config: Config): Promise<void> {
  // Always start by clearing our reserved rule range.
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const ourIds = existing
    .map(r => r.id)
    .filter(id => id >= RULE_ID_BASE && id <= RULE_ID_LIMIT);

  const newRules = config.lane.enabled ? buildLaneRules(config) : [];
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: ourIds,
    addRules: newRules,
  });
}

function buildLaneRules(config: Config): chrome.declarativeNetRequest.Rule[] {
  const headerEntries = Object.entries(config.lane.headers);
  const routes = config.lane.routes ?? [];
  if (headerEntries.length === 0 && routes.length === 0) return [];

  const rules: chrome.declarativeNetRequest.Rule[] = [];

  // Global rule: inject all headers from lane.headers into every request.
  if (headerEntries.length > 0) {
    rules.push({
      id: RULE_ID_BASE,
      priority: 1,
      action: {
        type: 'modifyHeaders' as chrome.declarativeNetRequest.RuleActionType,
        requestHeaders: headerEntries.map(([header, value]) => ({
          header,
          operation: 'set' as chrome.declarativeNetRequest.HeaderOperation,
          value,
        })),
      },
      condition: {
        resourceTypes: ALL_RESOURCE_TYPES,
        ...(config.lane.excludedDomains?.length
          ? { excludedRequestDomains: config.lane.excludedDomains }
          : {}),
      },
    });
  }

  // Per-route rules: override x-tt-env (+ derived x-use-ppe) for matched
  // domains. Priority 2 beats the global rule's priority 1, so the route env
  // wins for those domains while other global headers still apply.
  for (let i = 0; i < routes.length; i++) {
    const route = routes[i]!;
    const routeHeaders: chrome.declarativeNetRequest.ModifyHeaderInfo[] = [
      { header: 'x-tt-env', operation: 'set' as chrome.declarativeNetRequest.HeaderOperation, value: route.env },
    ];
    if (route.env.startsWith('ppe_')) {
      routeHeaders.push({ header: 'x-use-ppe', operation: 'set' as chrome.declarativeNetRequest.HeaderOperation, value: '1' });
    } else if (route.env.startsWith('boe_')) {
      routeHeaders.push({ header: 'x-use-ppe', operation: 'remove' as chrome.declarativeNetRequest.HeaderOperation });
    }
    rules.push({
      id: RULE_ID_BASE + 1 + i,
      priority: 2,
      action: {
        type: 'modifyHeaders' as chrome.declarativeNetRequest.RuleActionType,
        requestHeaders: routeHeaders,
      },
      condition: {
        requestDomains: route.domains,
        resourceTypes: ALL_RESOURCE_TYPES,
        ...(route.excludedDomains?.length
          ? { excludedRequestDomains: route.excludedDomains }
          : {}),
      },
    });
  }

  return rules;
}

const ALL_RESOURCE_TYPES = [
  'main_frame','sub_frame','stylesheet','script','image','font','object',
  'xmlhttprequest','ping','csp_report','media','websocket','webtransport',
  'webbundle','other',
] as unknown as chrome.declarativeNetRequest.ResourceType[];

async function applyProxy(config: Config): Promise<void> {
  // 'clear' would cede control back to Chrome's default — which itself follows
  // the OS — so even the direct case has to actively set mode:'direct' to
  // actually bypass an OS-level proxy entry. Per-URL routing belongs in the OS
  // proxy tool (or in `mode:'fixed'`'s upstream).
  const proxy = config.proxy;
  if (proxy.mode === 'fixed') {
    if (!proxy.server) throw new Error('proxy.mode=fixed requires proxy.server');
    const parsed = parseProxyServer(proxy.server);
    await chrome.proxy.settings.set({
      scope: 'regular',
      value: {
        mode: 'fixed_servers',
        rules: { singleProxy: parsed },
      },
    });
    return;
  }
  await chrome.proxy.settings.set({
    scope: 'regular',
    value: { mode: proxy.mode === 'system' ? 'system' : 'direct' },
  });
}

function parseProxyServer(server: string): chrome.proxy.ProxyServer {
  // Daemon already normalizes this to <scheme>://<host>:<port>, so URL parsing
  // is just defensive — but we still validate to surface a clean apply error
  // instead of letting chrome.proxy.settings.set throw a less helpful one.
  const url = new URL(server);
  const scheme = url.protocol.replace(/:$/, '').toLowerCase();
  const port = Number(url.port);
  if (!url.hostname || !Number.isFinite(port)) {
    throw new Error(`invalid proxy server: ${server}`);
  }
  return { scheme: scheme as chrome.proxy.ProxyServer['scheme'], host: url.hostname, port };
}

// ─── Toolbar icon ───────────────────────────────────────────────────

/**
 * Toolbar encodes two independent dimensions so single-knob states are
 * distinguishable at a glance:
 *   background — proxy mode (gray = direct, blue = system, green = fixed)
 *   L glyph    — lane state (bright white = on, dim white = off)
 *   disconnected gets its own darker palette so it stays unambiguous.
 *
 * Hover title carries the lane identifier so users can confirm which env
 * they're routed to without a badge cluttering the icon.
 */

type UIState =
  | 'disconnected'
  | 'off-direct'
  | 'off-system'
  | 'off-fixed'
  | 'on-direct'
  | 'on-system'
  | 'on-fixed';

const ICON_COLORS: Record<UIState, { bg: string; fg: string }> = {
  'disconnected': { bg: '#6b7280', fg: '#9ca3af' },
  'off-direct':   { bg: '#9ca3af', fg: 'rgba(255,255,255,0.45)' },
  'off-system':   { bg: '#2563eb', fg: 'rgba(255,255,255,0.45)' },
  'off-fixed':    { bg: '#16a34a', fg: 'rgba(255,255,255,0.45)' },
  'on-direct':    { bg: '#9ca3af', fg: '#ffffff' },
  'on-system':    { bg: '#2563eb', fg: '#ffffff' },
  'on-fixed':     { bg: '#16a34a', fg: '#ffffff' },
};

const ICON_SIZES = [16, 32, 48, 128] as const;
const iconCache = new Map<UIState, Record<number, ImageData>>();

function paintIcon(bg: string, fg: string, size: number): ImageData {
  const canvas = new OffscreenCanvas(size, size);
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('OffscreenCanvas 2D context unavailable');
  ctx.clearRect(0, 0, size, size);

  // Background: filled rounded square, ~95% of canvas.
  const pad = Math.max(1, Math.round(size * 0.05));
  const w = size - pad * 2;
  const radius = Math.max(2, size * 0.22);
  ctx.fillStyle = bg;
  if (typeof ctx.roundRect === 'function') {
    ctx.beginPath();
    ctx.roundRect(pad, pad, w, w, radius);
    ctx.fill();
  } else {
    ctx.fillRect(pad, pad, w, w);
  }

  // Foreground: "L" drawn as two integer-aligned rects so it stays crisp
  // at 16px (subpixel fillText looks fuzzy; fillText also depends on whatever
  // font the worker happens to resolve, which varies across platforms).
  const lPad = Math.round(size * 0.26);
  const lThick = Math.max(2, Math.round(size * 0.16));
  const lInner = size - lPad * 2;
  ctx.fillStyle = fg;
  ctx.fillRect(lPad, lPad, lThick, lInner);
  ctx.fillRect(lPad, size - lPad - lThick, lInner, lThick);

  return ctx.getImageData(0, 0, size, size);
}

function getIconImageData(state: UIState): Record<number, ImageData> {
  let cached = iconCache.get(state);
  if (cached) return cached;
  const { bg, fg } = ICON_COLORS[state];
  cached = {};
  for (const s of ICON_SIZES) cached[s] = paintIcon(bg, fg, s);
  iconCache.set(state, cached);
  return cached;
}

function computeUIState(connected: boolean, config: Config | null): UIState {
  if (!connected) return 'disconnected';
  const lane = config?.lane.enabled ? 'on' : 'off';
  const proxy = config?.proxy.mode ?? 'direct';
  return `${lane}-${proxy}` as UIState;
}

function laneSummary(config: Config | null): string {
  if (!config?.lane.enabled) return '';
  return config.lane.headers['x-tt-env'] || Object.values(config.lane.headers)[0] || '';
}

async function updateActionUI(): Promise<void> {
  const connected = ws?.readyState === WebSocket.OPEN;
  const ui = computeUIState(connected, lastConfig);

  try {
    await chrome.action.setIcon({ imageData: getIconImageData(ui) });
  } catch (err) {
    console.warn('[byted-lane] setIcon failed:', (err as Error).message);
  }

  const lane = laneSummary(lastConfig);
  const title = (() => {
    if (ui === 'disconnected') return 'byted-lane (daemon offline)';
    const [laneState, proxyState] = ui.split('-') as ['on' | 'off', 'direct' | 'system' | 'fixed'];
    const proxyDesc =
      proxyState === 'system' ? 'system proxy'
      : proxyState === 'fixed' ? `fixed proxy${lastConfig?.proxy.server ? ` ${lastConfig.proxy.server}` : ''}`
      : 'direct';
    const laneDesc = laneState === 'on' ? (lane ? `lane: ${lane}` : 'lane on') : 'lane off';
    return `byted-lane (${laneDesc} · ${proxyDesc})`;
  })();
  await chrome.action.setTitle({ title });
}

// ─── Persistence (popup state, recovery) ────────────────────────────

async function persistState(s: Persisted): Promise<void> {
  if (startupCache) startupCache.state = s;
  await chrome.storage.local.set({ [STATE_KEY]: s });
}

// ─── Popup messaging ────────────────────────────────────────────────

function readStartupCache(): Promise<StartupCache> {
  if (startupCache) return Promise.resolve(startupCache);
  if (startupCachePromise) return startupCachePromise;

  startupCachePromise = chrome.storage.local
    .get([STATE_KEY, AUTOSTART_CACHE_KEY, PROXY_RECOVERY_KEY])
    .then(raw => {
      startupCache = {
        state: (raw[STATE_KEY] as Persisted | undefined) ?? null,
        autostart: (raw[AUTOSTART_CACHE_KEY] as PersistedAutostart | undefined) ?? null,
        proxyRecovered: raw[PROXY_RECOVERY_KEY] === true,
      };
      return startupCache;
    })
    .finally(() => {
      startupCachePromise = null;
    });
  return startupCachePromise;
}

async function recoverStaleProxyOnce(cached: StartupCache): Promise<void> {
  if (cached.proxyRecovered) return;
  try {
    await chrome.proxy.settings.clear({ scope: 'regular' });
    cached.proxyRecovered = true;
    await chrome.storage.local.set({ [PROXY_RECOVERY_KEY]: true });
  } catch {
    // Retry on the next worker lifecycle if Chrome rejected the recovery.
  }
}

function refreshAutostart(): Promise<void> {
  if (autostartRefreshPromise) return autostartRefreshPromise;
  if (autostartCache && Date.now() - autostartCache.fetchedAt < AUTOSTART_CACHE_TTL_MS) {
    return Promise.resolve();
  }

  autostartRefreshPromise = (async () => {
    try {
      const res = await fetch(DAEMON_STATUS_URL, { signal: AbortSignal.timeout(800) });
      if (!res.ok) return;
      const body = await res.json() as DaemonStatus;
      if (!body.autostart) return;
      autostartCache = { value: body.autostart, fetchedAt: Date.now() };
      if (startupCache) startupCache.autostart = autostartCache;
      await chrome.storage.local.set({ [AUTOSTART_CACHE_KEY]: autostartCache });
    } catch {
      // If daemon is unavailable, keep the last known value. Connectivity is
      // already represented separately and is the actionable popup state.
    }
  })().finally(() => {
    autostartRefreshPromise = null;
  });
  return autostartRefreshPromise;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === 'popupPerf') {
    const timing = msg.timing as Record<string, unknown> | undefined;
    console.log('[byted-lane] popup perf', timing ?? {});
    sendResponse({ ok: true });
    return false;
  }
  if (msg?.type === 'getStatus') {
    void (async () => {
      // Opportunistically reconnect when popup opens — cheap fallback if
      // the alarm-based reconnection missed a cycle.
      if (!ws || ws.readyState !== WebSocket.OPEN) void connect();
      const cached = await readStartupCache();
      autostartCache = cached.autostart;
      void refreshAutostart();
      sendResponse({
        connected: ws?.readyState === WebSocket.OPEN,
        revision: cached.state?.revision ?? null,
        lastAppliedOk: cached.state?.lastAppliedOk ?? null,
        lastAppliedError: cached.state?.lastAppliedError ?? null,
        config: cached.state?.config ?? null,
        autostart: cached.autostart?.value ?? null,
      });
    })();
    return true; // keep channel open for async sendResponse
  }
  if (msg?.type === 'reconnect') {
    const pending = connectPromise;
    const previous = ws;
    ws = null;
    try { previous?.close(); } catch { /* ignore */ }
    void (async () => {
      if (pending) await pending;
      await connect();
    })();
    sendResponse({ ok: true });
    return false;
  }
  if (msg?.type === 'patchConfig') {
    // Popup edits config via daemon HTTP. Daemon's WS broadcast then re-applies
    // through the normal handleConfig path, so DNR/proxy stay in sync.
    void (async () => {
      try {
        const res = await fetch(DAEMON_CONFIG_URL, {
          method: 'PATCH',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(msg.patch ?? {}),
        });
        const text = await res.text();
        const body = text ? JSON.parse(text) : {};
        if (!res.ok) {
          sendResponse({ ok: false, error: (body as { error?: string }).error ?? `HTTP ${res.status}` });
        } else {
          const revision = (body as { revision?: number }).revision;
          if (typeof revision !== 'number') {
            sendResponse({ ok: false, error: 'daemon response did not include a revision' });
            return;
          }
          const outcome = await applyCoordinator.waitFor(revision);
          if (!outcome) {
            sendResponse({
              ok: false,
              error: `configuration saved as rev ${revision}, but apply confirmation timed out`,
            });
          } else if (!outcome.ok) {
            sendResponse({ ok: false, error: outcome.error ?? `failed to apply rev ${revision}` });
          } else {
            sendResponse({
              ok: true,
              revision: outcome.revision,
              config: (body as { config?: Config }).config,
            });
          }
        }
      } catch (err) {
        sendResponse({ ok: false, error: (err as Error).message });
      }
    })();
    return true;
  }
});

// ─── Lifecycle ──────────────────────────────────────────────────────

function initialize(): void {
  if (initialized) return;
  initialized = true;
  void (async () => {
    // One storage read hydrates every value needed by initialization and popup.
    const cached = await readStartupCache();
    lastConfig = cached.state?.config ?? null;
    autostartCache = cached.autostart;
    // Older builds could leave a loopback-breaking proxy rule behind. Recover
    // it once, not on every MV3 worker cold start.
    await recoverStaleProxyOnce(cached);
    // Restore the daemon connection before non-critical UI/autostart work.
    // This starts bidirectional keepalive as early as possible after a wake.
    await connect();
    void refreshAutostart();
    void (async () => {
      // Clear any badge left over from older builds that used to render one.
      try { await chrome.action.setBadgeText({ text: '' }); } catch { /* ignore */ }
      await updateActionUI();
    })();
  })();
  console.log('[byted-lane] extension initialized');
}

// Return the Promise so Chrome extends SW lifetime until connect() settles.
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === KEEPALIVE_ALARM) return connect();
});

chrome.runtime.onInstalled.addListener(() => initialize());
chrome.runtime.onStartup.addListener(() => initialize());

// Service worker may be revived by an event without onStartup firing in dev.
initialize();
