export interface ApplyOutcome {
  revision: number;
  ok: boolean;
  error?: string;
}

type Waiter = {
  resolve: (outcome: ApplyOutcome | null) => void;
  timer: ReturnType<typeof setTimeout>;
};

/**
 * Bridges the daemon PATCH response and the later WebSocket apply result.
 *
 * The popup knows the revision returned by PATCH /config, while the service
 * worker knows when that revision has actually reached DNR/proxy/storage. This
 * coordinator lets the message handler wait for the real apply event instead
 * of sleeping for an arbitrary amount of time.
 */
export class ApplyCoordinator {
  private latest: ApplyOutcome | null = null;
  private readonly waiters = new Map<number, Set<Waiter>>();

  constructor(private readonly timeoutMs: number) {}

  reset(): void {
    this.latest = null;
    for (const targetWaiters of this.waiters.values()) {
      for (const waiter of targetWaiters) {
        clearTimeout(waiter.timer);
        waiter.resolve(null);
      }
    }
    this.waiters.clear();
  }

  settle(outcome: ApplyOutcome): void {
    if (!this.latest || outcome.revision >= this.latest.revision) {
      this.latest = outcome;
    }

    for (const [targetRevision, targetWaiters] of this.waiters) {
      if (targetRevision > outcome.revision) continue;
      this.waiters.delete(targetRevision);
      for (const waiter of targetWaiters) {
        clearTimeout(waiter.timer);
        waiter.resolve(outcome);
      }
    }
  }

  waitFor(revision: number): Promise<ApplyOutcome | null> {
    if (this.latest && this.latest.revision >= revision) {
      return Promise.resolve(this.latest);
    }

    return new Promise(resolve => {
      const waiter: Waiter = {
        resolve,
        timer: setTimeout(() => {
          const targetWaiters = this.waiters.get(revision);
          targetWaiters?.delete(waiter);
          if (targetWaiters?.size === 0) this.waiters.delete(revision);
          resolve(null);
        }, this.timeoutMs),
      };
      const targetWaiters = this.waiters.get(revision) ?? new Set<Waiter>();
      targetWaiters.add(waiter);
      this.waiters.set(revision, targetWaiters);
    });
  }
}
