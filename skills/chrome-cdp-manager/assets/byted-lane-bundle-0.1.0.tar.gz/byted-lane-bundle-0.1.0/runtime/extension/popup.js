// byted-lane popup — persistent environment workspace.
//
// Environment profiles live in daemon config.json and are shared with the CLI.
// Chrome storage only keeps the selected sidebar item and a one-time migration
// marker for profiles created by older popup versions.

const LEGACY_PROFILE_KEY = 'byted_lane_profiles_v1';
const SELECTED_KEY = 'byted_lane_selected_profile_v1';
const PROFILE_MIGRATION_KEY = 'byted_lane_profiles_daemon_v1';
const popupNavigationStartedAt = Date.now();
const popupScriptStartedAt = performance.now();

let profilesCache = null;
let selectedProfileId = null;
let lastError = null;
let shouldReportInitialRender = true;

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else node.setAttribute(key, value);
  }
  for (const child of children) {
    if (child == null) continue;
    node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
  }
  return node;
}

function newId() {
  return globalThis.crypto?.randomUUID?.().slice(0, 8) ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function isValidEnv(env) {
  return typeof env === 'string' && (env.startsWith('ppe_') || env.startsWith('boe_'));
}

function envKind(env) {
  return env?.startsWith('boe_') ? 'boe' : env?.startsWith('ppe_') ? 'ppe' : 'draft';
}

function profileLabel(profile) {
  return profile.env || '新环境';
}

function profileInitial(profile) {
  const raw = (profile.env || 'new').replace(/^(ppe|boe)_/, '');
  return raw.slice(0, 1).toUpperCase() || 'N';
}

function activeFilterValues(filters) {
  return (filters ?? []).filter(item => item.enabled !== false && item.value?.trim()).map(item => item.value.trim().toLowerCase());
}

function blankProfile() {
  return {
    id: newId(), env: '', enabled: false, headers: {},
    includeFilters: [], excludeFilters: [],
    source: 'manual', createdAt: Date.now(), updatedAt: Date.now(),
  };
}

async function getStatus() {
  return chrome.runtime.sendMessage({ type: 'getStatus' });
}

async function patchConfig(patch) {
  return chrome.runtime.sendMessage({ type: 'patchConfig', patch });
}

async function saveSelection(selectedId = selectedProfileId) {
  selectedProfileId = selectedId;
  await chrome.storage.local.set({ [SELECTED_KEY]: selectedId });
}

async function loadProfiles(config) {
  if (profilesCache) return profilesCache;
  const raw = await chrome.storage.local.get([LEGACY_PROFILE_KEY, SELECTED_KEY, PROFILE_MIGRATION_KEY]);
  let profiles = Array.isArray(config?.environments) ? config.environments : [];
  selectedProfileId = typeof raw[SELECTED_KEY] === 'string' ? raw[SELECTED_KEY] : null;

  if (raw[PROFILE_MIGRATION_KEY] !== true) {
    const legacy = Array.isArray(raw[LEGACY_PROFILE_KEY]) ? raw[LEGACY_PROFILE_KEY] : [];
    const existingEnvs = new Set(profiles.map(profile => profile.env).filter(Boolean));
    for (const profile of legacy) {
      if (!profile || typeof profile !== 'object') continue;
      if (profile.env && existingEnvs.has(profile.env)) continue;
      profiles.push({ ...profile, enabled: false });
      if (profile.env) existingEnvs.add(profile.env);
    }
    if (legacy.length > 0) {
      const response = await patchConfig({ environments: profiles });
      if (response?.ok) profiles = response.config?.environments ?? profiles;
    }
    await chrome.storage.local.set({ [PROFILE_MIGRATION_KEY]: true });
  }

  if (profiles.length === 0) {
    profiles = [blankProfile()];
    const response = await patchConfig({ environments: profiles });
    if (response?.ok) profiles = response.config.environments;
  }
  if (!profiles.some(profile => profile.id === selectedProfileId)) {
    selectedProfileId = profiles.find(profile => profile.enabled)?.id ?? profiles[0]?.id ?? null;
    await saveSelection(selectedProfileId);
  }
  profilesCache = profiles;
  return profiles;
}

async function applyProfiles(profiles) {
  lastError = null;
  let response;
  try {
    response = await patchConfig({ environments: profiles });
  } catch (error) {
    lastError = `extension messaging error: ${error?.message ?? error}`;
    await render();
    return false;
  }
  if (!response?.ok) {
    lastError = response?.error ?? 'background did not respond — reload the extension';
    await render();
    return false;
  }
  profilesCache = response.config?.environments ?? profiles;
  await saveSelection();
  await render();
  return true;
}

async function selectProfile(id) {
  await saveSelection(id);
  await render();
}

async function toggleProfile(profile, next) {
  let profiles = (await loadProfiles()).map(item => ({ ...item }));
  const target = profiles.find(item => item.id === profile.id);
  if (!target) return;
  if (next && !isValidEnv(target.env)) {
    lastError = '请先填写以 ppe_ 或 boe_ 开头的环境名称。';
    await render();
    return;
  }
  if (next && activeFilterValues(target.includeFilters).length === 0) {
    profiles = profiles.map(item => item.id !== target.id && activeFilterValues(item.includeFilters).length === 0
      ? { ...item, enabled: false }
      : item);
  }
  const updated = profiles.find(item => item.id === target.id);
  updated.enabled = next;
  updated.updatedAt = Date.now();
  selectedProfileId = target.id;
  await applyProfiles(profiles);
}

async function updateProfile(id, mutate) {
  const profiles = (await loadProfiles()).map(profile => profile.id === id ? mutate({ ...profile }) : profile);
  const changed = profiles.find(profile => profile.id === id);
  if (changed) changed.updatedAt = Date.now();
  await applyProfiles(profiles);
}

const ICON_REFRESH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 11a8 8 0 1 0-2.34 5.66"/><path d="M20 4v7h-7"/></svg>';
const ICON_RECONNECT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 17H7A5 5 0 0 1 7 7h2M15 7h2a5 5 0 1 1 0 10h-2M8 12h8"/></svg>';

function iconButton(svg, label, onClick) {
  const button = el('button', { class: 'icon-btn', type: 'button', title: label, 'aria-label': label });
  button.innerHTML = svg;
  button.addEventListener('click', onClick);
  return button;
}

function header(status) {
  const laneOn = !!status.config?.lane?.enabled;
  const proxy = status.config?.proxy?.mode ?? 'direct';
  const proxyLabel = proxy === 'system' ? '系统代理' : proxy === 'fixed' ? '固定代理' : '直连';
  return el('header', { class: 'header' }, [
    el('div', { class: `brand ${status.connected ? `on-${proxy}` : 'disconnected'}`, text: 'L' }),
    el('div', { class: 'header-text' }, [
      el('div', { class: 'title', text: 'byted-lane' }),
      el('div', { class: 'subtitle', text: `${laneOn ? '泳道已开启' : '泳道已关闭'} · ${proxyLabel} · 版本 ${status.revision ?? '—'}` }),
    ]),
    el('div', { class: 'header-actions' }, [
      iconButton(ICON_REFRESH, '刷新', () => { profilesCache = null; lastError = null; void render(); }),
      iconButton(ICON_RECONNECT, '重新连接 daemon', async () => {
        await chrome.runtime.sendMessage({ type: 'reconnect' });
        setTimeout(() => { profilesCache = null; void render(); }, 300);
      }),
    ]),
  ]);
}

function sidebar(profiles, selectedId) {
  const list = el('nav', { class: 'profile-list', 'aria-label': '环境列表' });
  for (const profile of profiles) {
    const item = el('div', {
      class: `profile-nav-item ${profile.id === selectedId ? 'selected' : ''} ${profile.enabled ? 'enabled' : ''}`,
      role: 'button', tabindex: '0', title: profileLabel(profile),
    });
    const badge = el('span', { class: `profile-badge ${envKind(profile.env)}`, text: profileInitial(profile) });
    const toggle = el('button', {
      class: 'profile-status', type: 'button', role: 'switch',
      'aria-checked': String(!!profile.enabled),
      'aria-label': `${profileLabel(profile)}${profile.enabled ? '已启用' : '已停用'}`,
      text: profile.enabled ? '✓' : '−',
    });
    toggle.addEventListener('click', event => { event.stopPropagation(); void toggleProfile(profile, !profile.enabled); });
    item.append(badge, toggle);
    item.addEventListener('click', () => void selectProfile(profile.id));
    item.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); void selectProfile(profile.id); }
    });
    list.appendChild(item);
  }
  const add = el('button', { class: 'profile-add', type: 'button', text: '+', 'aria-label': '新建环境', title: '新建环境' });
  add.addEventListener('click', async () => {
    const profile = blankProfile();
    const next = [...profiles, profile];
    selectedProfileId = profile.id;
    await applyProfiles(next);
    requestAnimationFrame(() => document.querySelector('.profile-env-input')?.focus());
  });
  return el('aside', { class: 'sidebar' }, [list, add]);
}

function switchControl(profile) {
  const button = el('button', {
    class: `switch ${profile.enabled ? 'on' : ''}`, type: 'button', role: 'switch',
    'aria-checked': String(!!profile.enabled), 'aria-label': `${profileLabel(profile)}启用状态`,
  });
  button.addEventListener('click', () => void toggleProfile(profile, !profile.enabled));
  return button;
}

function filterSection(profile, key, title, help) {
  const filters = profile[key] ?? [];
  const section = el('section', { class: 'filter-section' });
  const add = el('button', { class: 'filter-add', type: 'button', text: '+ 添加' });
  const list = el('div', { class: 'filter-list' });
  const openForm = async () => {
    if (list.querySelector('.filter-new-input')) return;
    const input = el('input', { class: 'filter-new-input', type: 'text', placeholder: 'example.bytedance.net' });
    list.appendChild(input);
    const domain = await getActiveTabDomain();
    if (domain) input.value = domain;
    input.focus();
    input.select();
    let committed = false;
    const commit = async () => {
      if (committed) return;
      committed = true;
      const value = input.value.trim().toLowerCase();
      if (!value) { input.remove(); return; }
      await updateProfile(profile.id, next => {
        const current = next[key] ?? [];
        if (!current.some(item => item.value === value)) next[key] = [...current, { id: newId(), value, enabled: true }];
        return next;
      });
    };
    input.addEventListener('keydown', event => {
      if (event.key === 'Enter') input.blur();
      else if (event.key === 'Escape') { committed = true; input.remove(); }
    });
    input.addEventListener('blur', () => void commit());
  };
  add.addEventListener('click', () => void openForm());
  section.appendChild(el('div', { class: 'filter-head' }, [
    el('div', {}, [el('div', { class: 'filter-title', text: title }), el('div', { class: 'filter-help', text: help })]),
    add,
  ]));
  if (filters.length === 0) list.appendChild(el('div', { class: 'filter-empty', text: '暂无筛选条件，此环境将作用于所有域名。' }));
  for (const filter of filters) {
    const checkbox = el('input', { type: 'checkbox', 'aria-label': `启用 ${filter.value}` });
    checkbox.checked = filter.enabled !== false;
    checkbox.addEventListener('change', () => void updateProfile(profile.id, next => {
      next[key] = (next[key] ?? []).map(item => item.id === filter.id ? { ...item, enabled: checkbox.checked } : item);
      return next;
    }));
    const remove = el('button', { class: 'filter-remove', type: 'button', text: '×', 'aria-label': `删除 ${filter.value}` });
    remove.addEventListener('click', () => void updateProfile(profile.id, next => {
      next[key] = (next[key] ?? []).filter(item => item.id !== filter.id);
      return next;
    }));
    list.appendChild(el('div', { class: `filter-row ${filter.enabled === false ? 'off' : ''}` }, [checkbox, el('code', { text: filter.value }), remove]));
  }
  section.appendChild(list);
  return section;
}

function environmentPanel(profile, profiles) {
  const envInput = el('input', {
    class: `profile-env-input ${isValidEnv(profile.env) || !profile.env ? '' : 'invalid'}`,
    type: 'text', value: profile.env ?? '', placeholder: 'ppe_environment_name',
    'aria-label': '环境名称',
  });
  envInput.value = profile.env ?? '';
  envInput.addEventListener('change', async () => {
    const value = envInput.value.trim();
    if (value && !isValidEnv(value)) {
      lastError = '环境名称必须以 ppe_ 或 boe_ 开头。';
      await render();
      return;
    }
    await updateProfile(profile.id, next => ({ ...next, env: value }));
  });
  const remove = el('button', { class: 'profile-delete', type: 'button', text: '删除', 'aria-label': `删除 ${profileLabel(profile)}` });
  remove.addEventListener('click', async () => {
    let next = profiles.filter(item => item.id !== profile.id);
    if (next.length === 0) next = [blankProfile()];
    selectedProfileId = next[0].id;
    await applyProfiles(next);
  });
  const derived = profile.env?.startsWith('ppe_') ? '1' : profile.env?.startsWith('boe_') ? '已移除' : '—';
  return el('div', { class: 'environment-column' }, [
    el('section', { class: 'environment-panel' }, [
      el('div', { class: 'environment-head' }, [
        el('div', { class: 'environment-heading' }, [
          el('span', { class: `environment-dot ${profile.enabled ? 'on' : ''}` }),
          el('div', {}, [el('h2', { text: profile.env || '新环境' }), el('p', { text: profile.enabled ? '已启用并应用到 Chrome' : '已保存，当前未启用' })]),
        ]),
        el('div', { class: 'environment-actions' }, [remove, switchControl(profile)]),
      ]),
      el('div', { class: 'environment-fields' }, [
        el('label', { class: 'field-row' }, [el('span', { text: '环境' }), envInput]),
        el('div', { class: 'field-row' }, [el('span', { text: 'x-use-ppe' }), el('code', { text: derived })]),
      ]),
      filterSection(profile, 'includeFilters', '请求域名筛选', '设置后，此环境仅作用于这些域名。'),
      filterSection(profile, 'excludeFilters', '排除请求域名', '命中的域名不会使用此环境。'),
    ]),
    proxyPanel(),
  ]);
}

function proxyPanel() {
  const placeholder = el('div', { class: 'proxy-panel-slot' });
  return placeholder;
}

function renderProxy(proxy, mount) {
  const mode = proxy?.mode ?? 'direct';
  const segmented = el('div', { class: 'segmented' });
  for (const value of ['direct', 'system', 'fixed']) {
    const button = el('button', { class: `seg ${mode === value ? 'active' : ''}`, type: 'button', text: value });
    button.addEventListener('click', async () => {
      if (value === mode) return;
      const patch = value === 'fixed'
        ? { proxy: { mode: 'fixed', server: proxy?.server || 'http://127.0.0.1:8888' } }
        : { proxy: { mode: value } };
      const response = await patchConfig(patch);
      if (!response?.ok) lastError = response?.error ?? '代理更新失败';
      await render();
    });
    segmented.appendChild(button);
  }
  const descriptions = {
    direct: 'Chrome 不使用系统代理。',
    system: 'Chrome 跟随系统代理。',
    fixed: `Chrome 通过 ${proxy?.server ?? '固定代理'} 转发请求。`,
  };
  const modeLabels = { direct: '直连', system: '系统', fixed: '固定' };
  for (const [index, value] of ['direct', 'system', 'fixed'].entries()) {
    segmented.children[index].textContent = modeLabels[value];
  }
  mount.replaceWith(el('section', { class: 'proxy-panel' }, [
    el('div', { class: 'proxy-head' }, [el('h3', { text: 'Chrome 代理' }), segmented]),
    el('p', { text: descriptions[mode] }),
  ]));
}

async function getActiveTabDomain() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab?.url ? new URL(tab.url).hostname : '';
  } catch { return ''; }
}

function applyError(status) {
  if (status.lastAppliedOk !== false) return null;
  return el('div', { class: 'toast', text: `应用失败：${status.lastAppliedError ?? '未知错误'}` });
}

function offlineState() {
  return el('div', { class: 'offline' }, [el('strong', { text: 'Daemon 未连接' }), el('span', { text: '请运行 byted-lane start 后重新连接。' })]);
}

async function render() {
  const reportPerformance = shouldReportInitialRender;
  shouldReportInitialRender = false;
  const renderStartedAt = performance.now();
  const root = document.getElementById('root');
  let status;
  try { status = await getStatus(); }
  catch (error) {
    root.replaceChildren(offlineState());
    root.prepend(el('div', { class: 'toast', text: `扩展后台不可用：${error?.message ?? error}` }));
    return;
  }
  const statusReadyAt = performance.now();
  root.replaceChildren(header(status));
  if (lastError) root.appendChild(el('div', { class: 'toast', text: lastError }));
  const applyFailure = applyError(status);
  if (applyFailure) root.appendChild(applyFailure);
  if (!status.connected) {
    root.appendChild(offlineState());
    return;
  }
  const profiles = await loadProfiles(status.config);
  const profilesReadyAt = performance.now();
  const selected = profiles.find(profile => profile.id === selectedProfileId) ?? profiles[0];
  const panel = environmentPanel(selected, profiles);
  const layout = el('div', { class: 'workspace' }, [sidebar(profiles, selected.id), panel]);
  root.appendChild(layout);
  renderProxy(status.config?.proxy ?? { mode: 'direct' }, panel.querySelector('.proxy-panel-slot'));
  if (reportPerformance) reportPopupPerformance({ renderStartedAt, statusReadyAt, profilesReadyAt });
}

function reportPopupPerformance({ renderStartedAt, statusReadyAt, profilesReadyAt }) {
  setTimeout(() => {
    const completedAt = performance.now();
    const navigation = performance.getEntriesByType('navigation')[0];
    void chrome.runtime.sendMessage({
      type: 'popupPerf',
      timing: {
        wallStartedAt: popupNavigationStartedAt,
        scriptStartMs: popupScriptStartedAt,
        renderStartMs: renderStartedAt,
        statusMs: statusReadyAt - renderStartedAt,
        historyMs: profilesReadyAt - statusReadyAt,
        domMs: completedAt - profilesReadyAt,
        totalMs: completedAt,
        domInteractiveMs: navigation?.domInteractive ?? null,
        domContentLoadedMs: navigation?.domContentLoadedEventEnd ?? null,
        loadEventMs: navigation?.loadEventEnd ?? null,
      },
    }).catch(() => {});
  }, 0);
}

void render();
