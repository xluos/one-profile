/**
 * byted-lane shared protocol — daemon ↔ extension ↔ CLI.
 *
 * Single source of truth for: config schema, WS message envelope, daemon endpoints.
 */

// ─── Config schema ──────────────────────────────────────────────────

/** Domain-specific lane override — routes x-tt-env by Chrome DNR requestDomains. */
export interface LaneRoute {
  /** eTLD+1 domains. Chrome DNR matches these and all subdomains automatically. */
  domains: string[];
  /** Domains explicitly excluded from this route. */
  excludedDomains?: string[];
  /** x-tt-env value (ppe_* or boe_*). x-use-ppe is derived at apply time. */
  env: string;
}

export interface LaneConfig {
  /** Whether to inject lane headers at all. */
  enabled: boolean;
  /**
   * Header name → value pairs (e.g. {"x-tt-env":"boe_xxx","x-use-ppe":"1"}).
   * These are the global/default headers — injected on every request unless
   * overridden by a domain-specific route below.
   */
  headers: Record<string, string>;
  /** Domains excluded from the global/default header rule. */
  excludedDomains?: string[];
  /**
   * Domain-specific env overrides. Each route generates a higher-priority DNR
   * rule that sets x-tt-env (+ derived x-use-ppe) only for matching domains,
   * overriding the global env above. Unmatched domains still get the global
   * headers. Absent or empty means no domain-specific routing (backward compat).
   */
  routes?: LaneRoute[];
}

export interface EnvironmentFilter {
  id: string;
  value: string;
  enabled: boolean;
}

/** Persistent environment workspace shared by popup and CLI. */
export interface EnvironmentProfile {
  id: string;
  env: string;
  enabled: boolean;
  headers: Record<string, string>;
  includeFilters: EnvironmentFilter[];
  excludeFilters: EnvironmentFilter[];
  source?: 'current' | 'manual' | 'cli';
  createdAt: number;
  updatedAt: number;
}

/**
 * Proxy mode:
 *   'direct' — Chrome bypasses any OS proxy (force-direct).
 *   'system' — Chrome follows whatever the OS proxy says (SwitchyOmega /
 *              corporate proxy / debug tool's auto-installed proxy / etc).
 *   'fixed'  — Chrome routes through `server` (e.g. http://127.0.0.1:8899).
 *              Per-URL routing is intentionally not exposed; if you need it
 *              run an upstream PAC at the OS layer instead.
 */
export type ProxyMode = 'direct' | 'system' | 'fixed';

export interface ProxyConfig {
  mode: ProxyMode;
  /**
   * Required when mode === 'fixed'. Format: <scheme>://<host>:<port>
   * Supported schemes: http, https, socks4, socks5. Example: http://127.0.0.1:8899
   */
  server?: string;
}

export interface Config {
  lane: LaneConfig;
  environments: EnvironmentProfile[];
  proxy: ProxyConfig;
}

export const DEFAULT_CONFIG: Config = {
  lane: { enabled: false, headers: {} },
  environments: [],
  proxy: { mode: 'direct' },
};

// ─── Daemon constants ───────────────────────────────────────────────

export const DAEMON_HOST = '127.0.0.1';
export const DAEMON_PORT = 38999;
export const DAEMON_BASE = `http://${DAEMON_HOST}:${DAEMON_PORT}`;
export const DAEMON_PING_URL = `${DAEMON_BASE}/ping`;
export const DAEMON_CONFIG_URL = `${DAEMON_BASE}/config`;
export const DAEMON_STATUS_URL = `${DAEMON_BASE}/status`;
export const DAEMON_WS_URL = `ws://${DAEMON_HOST}:${DAEMON_PORT}/ext`;

export const PROTOCOL_VERSION = '0.1.0';
export const WS_RECONNECT_BASE_MS = 2000;
export const WS_RECONNECT_MAX_MS = 5000;

// ─── WebSocket envelope (daemon ↔ extension) ────────────────────────

export type ServerMessage =
  /** Pushed when extension connects, and again whenever config changes. */
  | { type: 'config'; config: Config; revision: number }
  /** Daemon response to an extension keepalive. The incoming WS event also resets MV3 idle time. */
  | { type: 'keepaliveAck'; ts: number };

export type ClientMessage =
  /** First message after connect. */
  | { type: 'hello'; extensionVersion: string; protocolVersion: string }
  /** Acknowledge a received config revision and report apply status. */
  | { type: 'applied'; revision: number; ok: boolean; error?: string }
  /** Bidirectional traffic used to keep the MV3 worker alive while the daemon is connected. */
  | { type: 'keepalive'; ts: number }
  /** Forward console logs to daemon for CLI debugging. */
  | { type: 'log'; level: 'info' | 'warn' | 'error'; msg: string; ts: number };

// ─── Status (HTTP /status) ──────────────────────────────────────────

/**
 * macOS launchd autostart state. `supported` is false on Linux/Windows; the
 * other two are only meaningful when supported is true. Surfaced in /status so
 * the popup can nudge users who haven't installed the LaunchAgent — without it,
 * the daemon won't come back after a reboot and there's no in-app signal that
 * anything is missing.
 */
export interface AutostartState {
  supported: boolean;
  installed: boolean;
  loaded: boolean;
}

export interface DaemonStatus {
  daemon: { version: string; pid: number; uptimeSec: number };
  extension: {
    connected: boolean;
    version?: string;
    protocolVersion?: string;
    lastAppliedRevision?: number;
    lastAppliedOk?: boolean;
    lastAppliedError?: string;
  };
  config: { revision: number; path: string };
  autostart: AutostartState;
}
