/**
 * Config persistence + change notification.
 *
 * Single source of truth lives on disk (~/.byted-lane/config.json). Both PUT /config
 * and external edits to the file flow through this store; subscribers get the
 * post-validation Config and a monotonically increasing revision.
 */

import { mkdir, readFile, writeFile, rename } from 'node:fs/promises';
import { watch, type FSWatcher } from 'node:fs';
import { homedir } from 'node:os';
import { basename, join, dirname } from 'node:path';
import {
  DEFAULT_CONFIG,
  type Config,
  type EnvironmentFilter,
  type EnvironmentProfile,
  type LaneRoute,
} from '../shared/protocol.ts';

export const CONFIG_DIR = join(homedir(), '.byted-lane');
export const CONFIG_PATH = join(CONFIG_DIR, 'config.json');

type Listener = (config: Config, revision: number) => void;

export class ConfigStore {
  private config: Config = DEFAULT_CONFIG;
  private revision = 0;
  private listeners = new Set<Listener>();
  private watcher: FSWatcher | null = null;
  private reloadTimer: ReturnType<typeof setTimeout> | null = null;
  private lastSerialized = '';

  async init(): Promise<void> {
    await mkdir(CONFIG_DIR, { recursive: true });
    try {
      const raw = await readFile(CONFIG_PATH, 'utf8');
      // Lenient on init: a stale config with a legacy/unprefixed env should
      // not prevent the daemon from booting. Strict prefix validation only
      // fires on user-driven writes (write/patch).
      this.config = validateConfig(JSON.parse(raw));
      this.lastSerialized = serialize(this.config);
      if (raw !== this.lastSerialized) await atomicWrite(CONFIG_PATH, this.lastSerialized);
    } catch (err: unknown) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') {
        this.config = DEFAULT_CONFIG;
        this.lastSerialized = serialize(this.config);
        await writeFile(CONFIG_PATH, this.lastSerialized, 'utf8');
      } else {
        throw new Error(`failed to read ${CONFIG_PATH}: ${(err as Error).message}`);
      }
    }
    this.revision = 1;
    this.startWatcher();
  }

  get current(): { config: Config; revision: number } {
    return { config: this.config, revision: this.revision };
  }

  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  /** Replace full config. Validates, writes atomically, bumps revision, notifies. */
  async write(next: unknown): Promise<{ config: Config; revision: number }> {
    const validated = validateConfig(next, { strict: true });
    const serialized = serialize(validated);
    if (serialized === this.lastSerialized) {
      // no-op write — keep revision stable
      return this.current;
    }
    await atomicWrite(CONFIG_PATH, serialized);
    this.lastSerialized = serialized;
    this.config = validated;
    this.revision++;
    this.notify();
    return this.current;
  }

  /** Shallow merge into top-level keys. Profile and legacy lane writes reconcile bidirectionally. */
  async patch(patch: Partial<Config>): Promise<{ config: Config; revision: number }> {
    const hasEnvironments = Object.prototype.hasOwnProperty.call(patch, 'environments');
    const hasLane = Object.prototype.hasOwnProperty.call(patch, 'lane');
    const lane = hasLane
      ? normalizeLane(validateLane({ ...this.config.lane, ...(patch.lane ?? {}) }, { strict: true }), { strict: true })
      : this.config.lane;
    const environments = hasEnvironments
      ? validateEnvironments(patch.environments, { strict: true })
      : hasLane
        ? reconcileEnvironmentsFromLane(lane, this.config.environments)
        : this.config.environments;
    const merged: Config = {
      lane: hasEnvironments ? compileEnvironments(environments, { strict: true }) : lane,
      environments,
      proxy: validateProxy({ ...this.config.proxy, ...(patch.proxy ?? {}) }),
    };
    return this.writeValidated(merged);
  }

  private async writeValidated(validated: Config): Promise<{ config: Config; revision: number }> {
    const serialized = serialize(validated);
    if (serialized === this.lastSerialized) return this.current;
    await atomicWrite(CONFIG_PATH, serialized);
    this.lastSerialized = serialized;
    this.config = validated;
    this.revision++;
    this.notify();
    return this.current;
  }

  async stop(): Promise<void> {
    this.watcher?.close();
    this.watcher = null;
    if (this.reloadTimer) clearTimeout(this.reloadTimer);
  }

  private startWatcher(): void {
    // Watch the parent directory rather than the file itself: atomic writes
    // (write-tmp + rename) swap the inode, which orphans a per-file watcher on
    // macOS. Directory watching is stable across renames.
    const targetName = basename(CONFIG_PATH);
    try {
      this.watcher = watch(CONFIG_DIR, (_event, filename) => {
        if (filename && filename !== targetName) return;
        if (this.reloadTimer) clearTimeout(this.reloadTimer);
        this.reloadTimer = setTimeout(() => void this.reloadFromDisk(), 100);
      });
    } catch (err) {
      console.warn('[byted-lane] config watcher unavailable:', (err as Error).message);
    }
  }

  private async reloadFromDisk(): Promise<void> {
    try {
      const raw = await readFile(CONFIG_PATH, 'utf8');
      if (raw === this.lastSerialized) return; // self-write or unchanged
      const next = validateConfig(JSON.parse(raw));
      const serialized = serialize(next);
      if (serialized === this.lastSerialized) {
        // The semantic config is unchanged, but the external edit contained
        // stale/derived fields. Put the canonical representation back on disk.
        if (raw !== serialized) await atomicWrite(CONFIG_PATH, serialized);
        return;
      }
      if (raw !== serialized) await atomicWrite(CONFIG_PATH, serialized);
      this.config = next;
      this.lastSerialized = serialized;
      this.revision++;
      this.notify();
    } catch (err) {
      console.warn('[byted-lane] config reload failed:', (err as Error).message);
    }
  }

  private notify(): void {
    for (const fn of this.listeners) {
      try { fn(this.config, this.revision); } catch (err) {
        console.error('[byted-lane] listener error:', err);
      }
    }
  }
}

// ─── Helpers ────────────────────────────────────────────────────────

function serialize(c: Config): string {
  return JSON.stringify(c, null, 2) + '\n';
}

async function atomicWrite(path: string, data: string): Promise<void> {
  const tmp = `${path}.tmp.${process.pid}.${Date.now()}`;
  await mkdir(dirname(path), { recursive: true });
  await writeFile(tmp, data, 'utf8');
  await rename(tmp, path);
}

function validateConfig(input: unknown, opts: { strict?: boolean } = {}): Config {
  if (!input || typeof input !== 'object') throw new Error('config must be an object');
  const obj = input as Record<string, unknown>;

  const validatedLane = normalizeLane(validateLane(obj.lane, opts), opts);
  const hasEnvironments = Object.prototype.hasOwnProperty.call(obj, 'environments');
  const environments = hasEnvironments
    ? validateEnvironments(obj.environments, opts)
    : environmentsFromLane(validatedLane);
  const lane = hasEnvironments ? compileEnvironments(environments, opts) : validatedLane;
  const proxy = validateProxy(obj.proxy);
  return { lane, environments, proxy };
}

function newId(): string {
  return crypto.randomUUID().slice(0, 8);
}

function validateEnvironmentFilter(input: unknown, path: string): EnvironmentFilter {
  if (!input || typeof input !== 'object') throw new Error(`${path} must be an object`);
  const obj = input as Record<string, unknown>;
  if (typeof obj.value !== 'string' || obj.value.trim() === '') {
    throw new Error(`${path}.value must be a non-empty domain`);
  }
  return {
    id: typeof obj.id === 'string' && obj.id.trim() ? obj.id.trim() : newId(),
    value: obj.value.trim().toLowerCase(),
    enabled: obj.enabled !== false,
  };
}

function validateEnvironments(input: unknown, opts: { strict?: boolean } = {}): EnvironmentProfile[] {
  if (input == null) return [];
  if (!Array.isArray(input)) throw new Error('environments must be an array');
  const seen = new Set<string>();
  const now = Date.now();
  const profiles = input.map((entry, index): EnvironmentProfile => {
    if (!entry || typeof entry !== 'object') throw new Error(`environments[${index}] must be an object`);
    const obj = entry as Record<string, unknown>;
    const env = typeof obj.env === 'string' ? obj.env.trim() : '';
    if (env && opts.strict && !env.startsWith('ppe_') && !env.startsWith('boe_')) {
      throw new Error(`environments[${index}].env must start with "ppe_" or "boe_" (got "${env}")`);
    }
    if (env && seen.has(env)) throw new Error(`duplicate environment env: "${env}"`);
    if (env) seen.add(env);
    const enabled = obj.enabled === true;
    if (enabled && !env) throw new Error(`environments[${index}].env is required when enabled`);
    const headers = obj.headers && typeof obj.headers === 'object'
      ? validateLane({ enabled: false, headers: obj.headers }, opts).headers
      : {};
    delete headers['x-tt-env'];
    delete headers['x-use-ppe'];
    const source = obj.source === 'current' || obj.source === 'manual' || obj.source === 'cli'
      ? obj.source
      : undefined;
    return {
      id: typeof obj.id === 'string' && obj.id.trim() ? obj.id.trim() : newId(),
      env,
      enabled,
      headers,
      includeFilters: Array.isArray(obj.includeFilters)
        ? obj.includeFilters.map((filter, filterIndex) => validateEnvironmentFilter(filter, `environments[${index}].includeFilters[${filterIndex}]`))
        : [],
      excludeFilters: Array.isArray(obj.excludeFilters)
        ? obj.excludeFilters.map((filter, filterIndex) => validateEnvironmentFilter(filter, `environments[${index}].excludeFilters[${filterIndex}]`))
        : [],
      ...(source ? { source } : {}),
      createdAt: typeof obj.createdAt === 'number' ? obj.createdAt : now,
      updatedAt: typeof obj.updatedAt === 'number' ? obj.updatedAt : now,
    };
  });
  const globalEnabled = profiles.filter(profile => profile.enabled && activeFilterValues(profile.includeFilters).length === 0);
  if (globalEnabled.length > 1) throw new Error('only one enabled environment without include filters is allowed');
  return profiles;
}

function activeFilterValues(filters: EnvironmentFilter[]): string[] {
  return [...new Set(filters.filter(filter => filter.enabled).map(filter => filter.value))];
}

function compileEnvironments(environments: EnvironmentProfile[], opts: { strict?: boolean } = {}): Config['lane'] {
  const enabled = environments.filter(profile => profile.enabled);
  const globalProfile = enabled.find(profile => activeFilterValues(profile.includeFilters).length === 0);
  const headers = globalProfile
    ? { ...globalProfile.headers, 'x-tt-env': globalProfile.env }
    : {};
  const excludedDomains = globalProfile ? activeFilterValues(globalProfile.excludeFilters) : [];
  const routes = enabled
    .filter(profile => activeFilterValues(profile.includeFilters).length > 0)
    .map(profile => {
      const route: LaneRoute = {
        env: profile.env,
        domains: activeFilterValues(profile.includeFilters),
      };
      const excluded = activeFilterValues(profile.excludeFilters);
      if (excluded.length) route.excludedDomains = excluded;
      return route;
    });
  return normalizeLane({ enabled: enabled.length > 0, headers, excludedDomains, routes }, opts);
}

function makeFilters(values: string[], current: EnvironmentFilter[] = []): EnvironmentFilter[] {
  return values.map(value => current.find(filter => filter.value === value)
    ?? { id: newId(), value, enabled: true });
}

function environmentsFromLane(lane: Config['lane']): EnvironmentProfile[] {
  return reconcileEnvironmentsFromLane(lane, []);
}

function reconcileEnvironmentsFromLane(lane: Config['lane'], currentProfiles: EnvironmentProfile[]): EnvironmentProfile[] {
  const now = Date.now();
  const profiles = currentProfiles.map(profile => ({ ...profile, enabled: false }));
  const upsert = (env: string, includes: string[], excludes: string[], headers: Record<string, string>) => {
    let profile = profiles.find(item => item.env === env);
    if (!profile) {
      profile = {
        id: newId(), env, enabled: false, headers: {}, includeFilters: [], excludeFilters: [],
        source: 'current', createdAt: now, updatedAt: now,
      };
      profiles.push(profile);
    }
    profile.enabled = lane.enabled;
    profile.headers = headers;
    profile.includeFilters = makeFilters(includes, profile.includeFilters);
    profile.excludeFilters = makeFilters(excludes, profile.excludeFilters);
    profile.updatedAt = now;
  };

  const globalEnv = lane.headers['x-tt-env'];
  if (globalEnv) {
    const headers = { ...lane.headers };
    delete headers['x-tt-env'];
    delete headers['x-use-ppe'];
    upsert(globalEnv, [], lane.excludedDomains ?? [], headers);
  }
  for (const route of lane.routes ?? []) {
    // A single profile cannot be global and scoped simultaneously. Preserve the
    // global form when legacy lane config contains the same env in both places.
    if (route.env === globalEnv) continue;
    upsert(route.env, route.domains, route.excludedDomains ?? [], {});
  }
  return profiles;
}

/**
 * ByteDance lane convention: `x-tt-env` prefix dictates whether `x-use-ppe`
 * must accompany it.
 *   - ppe_*  → x-use-ppe must be "1" (force-add)
 *   - boe_*  → x-use-ppe must be absent (force-strip; otherwise the request
 *              gets routed to PPE infra even though the env points at BOE)
 *   - other  → invalid in strict mode (PUT/PATCH); left alone in lenient mode
 *              (init/file-watch) so a stale legacy config can't brick the daemon.
 *
 * Applied at validation time so PUT/PATCH and external file edits both get
 * normalized — keeps the on-disk config and the broadcast config in sync.
 */
function normalizeLane(lane: Config['lane'], opts: { strict?: boolean } = {}): Config['lane'] {
  const env = lane.headers['x-tt-env'];
  if (typeof env !== 'string' || env === '') return lane;
  const headers = { ...lane.headers };
  if (env.startsWith('ppe_')) {
    headers['x-use-ppe'] = '1';
    return { ...lane, headers };
  }
  if (env.startsWith('boe_')) {
    delete headers['x-use-ppe'];
    return { ...lane, headers };
  }
  if (opts.strict) {
    throw new Error(`x-tt-env must start with "ppe_" or "boe_" (got "${env}")`);
  }
  return lane;
}

function validateLane(input: unknown, opts: { strict?: boolean } = {}): Config['lane'] {
  if (input == null) return { ...DEFAULT_CONFIG.lane };
  if (typeof input !== 'object') throw new Error('lane must be an object');
  const obj = input as Record<string, unknown>;

  const enabled = typeof obj.enabled === 'boolean' ? obj.enabled : false;
  const headers = obj.headers && typeof obj.headers === 'object'
    ? Object.fromEntries(
        Object.entries(obj.headers as Record<string, unknown>).map(([k, v]) => {
          if (typeof v !== 'string') throw new Error(`lane.headers["${k}"] must be a string`);
          if (!/^[A-Za-z0-9!#$%&'*+\-.^_`|~]+$/.test(k)) throw new Error(`invalid header name: ${k}`);
          return [k.toLowerCase(), v];
        }),
      )
    : {};

  const routes = validateRoutes(obj.routes, opts);
  const result: Config['lane'] = { enabled, headers };
  const excludedDomains = validateDomains(obj.excludedDomains, 'lane.excludedDomains');
  if (excludedDomains.length > 0) result.excludedDomains = excludedDomains;
  if (routes.length > 0) result.routes = routes;
  return result;
}

function validateDomains(input: unknown, path: string): string[] {
  if (input == null) return [];
  if (!Array.isArray(input)) throw new Error(`${path} must be a string array`);
  return [...new Set(input.map((value, i) => {
    if (typeof value !== 'string' || value.trim() === '') {
      throw new Error(`${path}[${i}] must be a non-empty string`);
    }
    return value.trim().toLowerCase();
  }))];
}

function validateRoutes(input: unknown, opts: { strict?: boolean } = {}): LaneRoute[] {
  if (input == null || !Array.isArray(input)) return [];
  return input.map((entry, i) => {
    if (!entry || typeof entry !== 'object') throw new Error(`lane.routes[${i}] must be an object`);
    const r = entry as Record<string, unknown>;
    if (!Array.isArray(r.domains) || r.domains.length === 0) {
      throw new Error(`lane.routes[${i}].domains must be a non-empty string array`);
    }
    for (const d of r.domains) {
      if (typeof d !== 'string' || d.trim() === '') {
        throw new Error(`lane.routes[${i}].domains contains invalid entry: ${JSON.stringify(d)}`);
      }
    }
    if (typeof r.env !== 'string' || r.env.trim() === '') {
      throw new Error(`lane.routes[${i}].env must be a non-empty string`);
    }
    const env = r.env.trim();
    if (opts.strict && !env.startsWith('ppe_') && !env.startsWith('boe_')) {
      throw new Error(`lane.routes[${i}].env must start with "ppe_" or "boe_" (got "${env}")`);
    }
    const route: LaneRoute = {
      domains: [...new Set(r.domains.map((d: string) => d.trim().toLowerCase()))],
      env,
    };
    const excludedDomains = validateDomains(r.excludedDomains, `lane.routes[${i}].excludedDomains`);
    if (excludedDomains.length > 0) route.excludedDomains = excludedDomains;
    return route;
  });
}

function validateProxy(input: unknown): Config['proxy'] {
  if (input == null) return { ...DEFAULT_CONFIG.proxy };
  if (typeof input !== 'object') throw new Error('proxy must be an object');
  const obj = input as Record<string, unknown>;

  // Resolve mode. Prefer the new `mode` field; fall back to legacy `enabled`
  // bool so configs from earlier versions keep working without manual edits.
  let mode: Config['proxy']['mode'];
  if (typeof obj.mode === 'string') {
    if (obj.mode !== 'direct' && obj.mode !== 'system' && obj.mode !== 'fixed') {
      throw new Error(`proxy.mode must be 'direct' | 'system' | 'fixed' (got "${obj.mode}")`);
    }
    mode = obj.mode;
  } else if (typeof obj.enabled === 'boolean') {
    mode = obj.enabled ? 'system' : 'direct';
  } else {
    mode = 'direct';
  }

  let server: string | undefined;
  if (typeof obj.server === 'string' && obj.server.trim() !== '') {
    server = normalizeProxyServer(obj.server.trim());
  }

  if (mode === 'fixed' && !server) {
    throw new Error('proxy.mode = "fixed" requires proxy.server (e.g. "http://127.0.0.1:8899")');
  }

  return server ? { mode, server } : { mode };
}

/**
 * Accept the loose forms users naturally type — "127.0.0.1:8899", "http://...",
 * "socks5://..." — and produce the canonical `<scheme>://<host>:<port>` we
 * store and hand to chrome.proxy. Returning errors here (instead of in the
 * extension) keeps the daemon as the validation choke point.
 */
function normalizeProxyServer(raw: string): string {
  // No scheme → assume http (Chrome's default for fixed_servers).
  const withScheme = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : `http://${raw}`;
  let url: URL;
  try { url = new URL(withScheme); }
  catch { throw new Error(`proxy.server is not a valid URL: ${raw}`); }
  const scheme = url.protocol.replace(/:$/, '').toLowerCase();
  if (!['http', 'https', 'socks4', 'socks5'].includes(scheme)) {
    throw new Error(`proxy.server scheme must be http/https/socks4/socks5 (got "${scheme}")`);
  }
  if (!url.hostname) throw new Error(`proxy.server missing host: ${raw}`);
  if (!url.port) throw new Error(`proxy.server missing port: ${raw}`);
  return `${scheme}://${url.hostname}:${url.port}`;
}
