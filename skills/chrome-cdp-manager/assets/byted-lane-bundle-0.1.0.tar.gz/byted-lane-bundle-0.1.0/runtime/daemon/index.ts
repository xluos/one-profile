/**
 * byted-lane daemon.
 *
 * Routes:
 *   GET  /ping       → { ok: true } (extension probes this before opening WS)
 *   GET  /config     → current Config + revision
 *   PUT  /config     → replace full config (body: Config)
 *   PATCH /config    → shallow merge {lane?, proxy?} into current
 *   GET  /status     → daemon + extension state
 *   WS   /ext        → extension subscription channel
 */

import { platform } from 'node:os';
import type { ServerWebSocket } from 'bun';
import { ConfigStore, CONFIG_PATH } from './config-store.ts';
import {
  DAEMON_HOST,
  DAEMON_PORT,
  PROTOCOL_VERSION,
  type ClientMessage,
  type DaemonStatus,
  type ServerMessage,
} from '../shared/protocol.ts';
import { autostartStatus } from '../cli/autostart.ts';

interface ExtensionState {
  version?: string;
  protocolVersion?: string;
  lastAppliedRevision?: number;
  lastAppliedOk?: boolean;
  lastAppliedError?: string;
}

interface ExtSocket {
  id: string;
  state: ExtensionState;
}

type ExtWS = ServerWebSocket<ExtSocket>;

const startedAt = Date.now();
const store = new ConfigStore();
await store.init();

// Track currently connected extension sockets. We only ever care about the
// most recent one — multiple Chrome profiles is an edge case we punt on for v1.
const sockets = new Map<ExtWS, ExtSocket>();

function broadcastConfig(): void {
  const { config, revision } = store.current;
  const msg: ServerMessage = { type: 'config', config, revision };
  const json = JSON.stringify(msg);
  for (const ws of sockets.keys()) {
    if (ws.readyState === 1 /* OPEN */) ws.send(json);
  }
}

store.subscribe(() => broadcastConfig());

function jsonResponse(body: unknown, init: number | ResponseInit = 200): Response {
  const status = typeof init === 'number' ? init : (init.status ?? 200);
  return new Response(JSON.stringify(body, null, 2) + '\n', {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8' },
  });
}

function errorResponse(status: number, message: string): Response {
  return jsonResponse({ ok: false, error: message }, status);
}

async function buildStatus(): Promise<DaemonStatus> {
  const { revision } = store.current;
  const first = sockets.values().next().value;
  const supported = platform() === 'darwin';
  // autostartStatus is safe on non-mac (no assertMac), it'll just report
  // installed:false because the plist path doesn't exist. We still report
  // supported:false so the popup can hide the hint instead of nagging users
  // who can't act on it.
  const a = await autostartStatus();
  return {
    daemon: {
      version: PROTOCOL_VERSION,
      pid: process.pid,
      uptimeSec: Math.round((Date.now() - startedAt) / 1000),
    },
    extension: first
      ? { connected: true, ...first.state }
      : { connected: false },
    config: { revision, path: CONFIG_PATH },
    autostart: {
      supported,
      installed: supported && a.installed,
      loaded: supported && a.loaded,
    },
  };
}

const server = Bun.serve<ExtSocket>({
  hostname: process.env.BYTED_LANE_HOST || DAEMON_HOST,
  port: Number(process.env.BYTED_LANE_PORT || DAEMON_PORT),
  async fetch(req, srv) {
    const url = new URL(req.url);

    if (url.pathname === '/ext') {
      const id = crypto.randomUUID().slice(0, 8);
      const ok = srv.upgrade(req, { data: { id, state: {} } });
      if (ok) return undefined as unknown as Response;
      return errorResponse(400, 'expected websocket upgrade');
    }

    if (url.pathname === '/ping' && req.method === 'GET') {
      return jsonResponse({ ok: true, version: PROTOCOL_VERSION });
    }

    if (url.pathname === '/config' && req.method === 'GET') {
      const { config, revision } = store.current;
      return jsonResponse({ config, revision });
    }

    if (url.pathname === '/config' && (req.method === 'PUT' || req.method === 'PATCH')) {
      let body: unknown;
      try { body = await req.json(); } catch { return errorResponse(400, 'invalid JSON body'); }
      try {
        const { config, revision } = req.method === 'PUT'
          ? await store.write(body)
          : await store.patch(body as Parameters<ConfigStore['patch']>[0]);
        return jsonResponse({ ok: true, config, revision });
      } catch (err) {
        return errorResponse(400, (err as Error).message);
      }
    }

    if (url.pathname === '/status' && req.method === 'GET') {
      return jsonResponse(await buildStatus());
    }

    return errorResponse(404, `no route for ${req.method} ${url.pathname}`);
  },
  websocket: {
    open(ws) {
      sockets.set(ws, ws.data);
      const { config, revision } = store.current;
      const msg: ServerMessage = { type: 'config', config, revision };
      ws.send(JSON.stringify(msg));
      console.log(`[byted-lane] extension connected (${ws.data.id}); ${sockets.size} total`);
    },
    message(ws, raw) {
      let parsed: ClientMessage;
      try { parsed = JSON.parse(String(raw)) as ClientMessage; }
      catch { console.warn('[byted-lane] bad WS payload:', raw); return; }

      const sock = sockets.get(ws);
      if (!sock) return;

      switch (parsed.type) {
        case 'hello':
          sock.state.version = parsed.extensionVersion;
          sock.state.protocolVersion = parsed.protocolVersion;
          console.log(`[byted-lane] hello from ext v${parsed.extensionVersion} (proto ${parsed.protocolVersion})`);
          break;
        case 'applied':
          sock.state.lastAppliedRevision = parsed.revision;
          sock.state.lastAppliedOk = parsed.ok;
          sock.state.lastAppliedError = parsed.error;
          if (parsed.ok) {
            console.log(`[byted-lane] ext applied rev ${parsed.revision}`);
          } else {
            console.warn(`[byted-lane] ext apply failed rev ${parsed.revision}: ${parsed.error}`);
          }
          break;
        case 'keepalive': {
          const ack: ServerMessage = { type: 'keepaliveAck', ts: parsed.ts };
          ws.send(JSON.stringify(ack));
          break;
        }
        case 'log':
          console.log(`[ext:${parsed.level}] ${parsed.msg}`);
          break;
      }
    },
    close(ws) {
      sockets.delete(ws);
      console.log(`[byted-lane] extension disconnected (${ws.data.id}); ${sockets.size} remaining`);
    },
  },
});

console.log(`[byted-lane] daemon listening on http://${server.hostname}:${server.port}`);
console.log(`[byted-lane] config: ${CONFIG_PATH}`);

const shutdown = async () => {
  console.log('[byted-lane] shutting down…');
  await store.stop();
  server.stop(true);
  process.exit(0);
};
process.on('SIGINT', () => void shutdown());
process.on('SIGTERM', () => void shutdown());
